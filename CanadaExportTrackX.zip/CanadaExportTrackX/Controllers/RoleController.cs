﻿using DocumentFormat.OpenXml.Drawing.Diagrams;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using CanadaExportTrackX.DataModel;
using CanadaExportTrackX.ViewModels;

namespace ModelOfficeTrackXI.Controllers
{
    public class RoleController : Controller
    {
        private readonly UserManager<ApplicationUser> userManger;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly RoleManager<Role> roleManager;
        public ApplicationDBContext _ctx;


        public RoleController(UserManager<ApplicationUser> userManger, SignInManager<ApplicationUser> signInManager, RoleManager<Role> roleManager, ApplicationDBContext ctx)
        {
            this.userManger = userManger;
            this.signInManager = signInManager;
            this.roleManager = roleManager;
            _ctx = ctx;
        }
        public IActionResult Index()
        {
            ViewData["Roles"] = _ctx.Roles.Where(x => x.IsDelete == false).ToList();
            var result = _ctx.Roles.Select(x => new RegisterRoleViewModel
            {
                Id = x.Id,
                Name = x.Name,
                NormalizedName = x.NormalizedName,
                IsActive = x.IsActive,
                IsDelete = x.IsDelete,
            }).OrderBy(x => x.Name).Where(x => x.IsDelete == false).ToList();

            return View(result);
        }
        public IActionResult DeletedRole()
        {
            ViewData["Roles"] = _ctx.Roles.Where(x => x.IsDelete == false).ToList();
            var result = _ctx.Roles.Select(x => new RegisterRoleViewModel
            {
                Id = x.Id,
                Name = x.Name,
                NormalizedName = x.NormalizedName,
                IsActive = x.IsActive,
                IsDelete = x.IsDelete,
            }).OrderBy(x => x.Name).Where(x => (x.IsActive == null && x.IsDelete == null) || ((x.IsActive == true || x.IsActive == false || x.IsActive == null) && (x.IsDelete == true || x.IsDelete == null)) || (x.IsDelete == true || x.IsDelete == null || x.IsActive == null)).ToList();

            return View(result);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin,IC")]
        [HttpGet]
        public IActionResult RegisterRole()
        {
            ViewData["Roles"] = _ctx.Roles.ToList();


            return View(new RegisterRoleViewModel());
        }
        [HttpPost]
        public async Task<IActionResult> RegisterRole(RegisterRoleViewModel model)
        {
            if (ModelState.IsValid)
            {
                var roleList = _ctx.Roles.Where(x => x.Name.ToLower() == model.Name.ToLower()).ToList();

                if (roleList == null || roleList.Count == 0)
                {
                    var role = new Role
                    {
                        Name = model.Name,
                        IsActive = true,
                        IsDelete = false,
                    };

                    var result = await roleManager.CreateAsync(role);
                    _ctx.SaveChanges();
                    //if (result.Succeeded)
                    //{
                    //    //await userManger.AddToRoleAsync(user, model.Role);

                    //    return RedirectToAction("Index", "Account");
                    //}
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                        return Json("error");
                    }
                }
                else
                {
                    return Json("duplicate");
                }
            }

            return Json("success");
        }

        [Authorize(Roles = "Supervisor,Manager,Admin,IC")]
        [HttpGet]
        public IActionResult EditRole(string roleId)
        {
            ViewData["EditRole"] = _ctx.Roles.Where(x => x.Id == roleId && x.IsActive == true && x.IsDelete == false).FirstOrDefault();

            return PartialView();
        }

        [HttpPost]
        [Authorize(Roles = "Supervisor, Manager, Admin")]
        public async Task<JsonResult> EditRole(RegisterRoleViewModel model)
        {
            var role = _ctx.Roles.Where(x => x.Id == model.Id && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
            if (role != null)
            {
                role.Name = model.Name.Trim();
                _ctx.Roles.Update(role);
                _ctx.SaveChanges();
                return Json("Updated Successfully..!");
            }
            else
            {
                return Json("Error while processing the request");
            }
        }

        [Authorize(Roles = "Supervisor, Manager, Admin")]
        public JsonResult ActivateRole(string Id)
        {
            string message = "";
            if (Id != null)
            {
                Role master = _ctx.Roles.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    //master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _ctx.Roles.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.Name + " Role Activated!" : master.Name + " Role Deactivated!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor, Manager, Admin")]
        public JsonResult DeleteRole(string Id)
        {
            string message = "";
            if (Id != null)
            {
                Role master = _ctx.Roles.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _ctx.Roles.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsDelete == true ? master.Name + " Role Deleted!" : master.Name + " Role Restore!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

    }
}
