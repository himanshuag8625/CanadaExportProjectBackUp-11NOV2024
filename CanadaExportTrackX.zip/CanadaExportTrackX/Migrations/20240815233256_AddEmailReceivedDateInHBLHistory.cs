﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CanadaExportTrackX.Migrations
{
    public partial class AddEmailReceivedDateInHBLHistory : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "EmailReceiveDate",
                table: "HBLActivitylogHistory",
                type: "datetime2",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EmailReceiveDate",
                table: "HBLActivitylogHistory");
        }
    }
}
