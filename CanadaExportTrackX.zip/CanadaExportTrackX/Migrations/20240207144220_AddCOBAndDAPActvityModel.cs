﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CanadaExportTrackX.Migrations
{
    public partial class AddCOBAndDAPActvityModel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "COBActivityId",
                table: "FileAcitivityLogHistory",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "COBActivity",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ContainerId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Booking = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    USABooking = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ETD = table.Column<DateTime>(type: "datetime2", nullable: true),
                    StatusId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ActivityId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_COBActivity", x => x.Id);
                    table.ForeignKey(
                        name: "FK_COBActivity_ActivityMaster_ActivityId",
                        column: x => x.ActivityId,
                        principalTable: "ActivityMaster",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_COBActivity_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_COBActivity_ContainerMaster_ContainerId",
                        column: x => x.ContainerId,
                        principalTable: "ContainerMaster",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_COBActivity_StatusMaster_StatusId",
                        column: x => x.StatusId,
                        principalTable: "StatusMaster",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "DAPActivity",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ContainerId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    HBLId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Booking = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    USABooking = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    VesselETA = table.Column<DateTime>(type: "datetime2", nullable: true),
                    FirstReminder = table.Column<DateTime>(type: "datetime2", nullable: true),
                    FirstReminderComment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FirstReminderStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SecondReminder = table.Column<DateTime>(type: "datetime2", nullable: true),
                    SecondReminderComment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SecondReminderStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ThirdReminder = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ThirdReminderComment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ThirdReminderStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StatusId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DAPActivity", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DAPActivity_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_DAPActivity_ContainerMaster_ContainerId",
                        column: x => x.ContainerId,
                        principalTable: "ContainerMaster",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DAPActivity_HBLMaster_HBLId",
                        column: x => x.HBLId,
                        principalTable: "HBLMaster",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_DAPActivity_StatusMaster_StatusId",
                        column: x => x.StatusId,
                        principalTable: "StatusMaster",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "DAPActvityHistory",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    DapActivityId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    USABooking = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    VesselETA = table.Column<DateTime>(type: "datetime2", nullable: true),
                    FirstReminder = table.Column<DateTime>(type: "datetime2", nullable: true),
                    FirstReminderComment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FirstReminderStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SecondReminder = table.Column<DateTime>(type: "datetime2", nullable: true),
                    SecondReminderComment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SecondReminderStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ThirdReminder = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ThirdReminderComment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ThirdReminderStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StatusId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ContainerId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    HBLId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DAPActvityHistory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DAPActvityHistory_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_DAPActvityHistory_ContainerMaster_ContainerId",
                        column: x => x.ContainerId,
                        principalTable: "ContainerMaster",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_DAPActvityHistory_DAPActivity_DapActivityId",
                        column: x => x.DapActivityId,
                        principalTable: "DAPActivity",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DAPActvityHistory_HBLMaster_HBLId",
                        column: x => x.HBLId,
                        principalTable: "HBLMaster",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_DAPActvityHistory_StatusMaster_StatusId",
                        column: x => x.StatusId,
                        principalTable: "StatusMaster",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_FileAcitivityLogHistory_COBActivityId",
                table: "FileAcitivityLogHistory",
                column: "COBActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_COBActivity_ActivityId",
                table: "COBActivity",
                column: "ActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_COBActivity_ContainerId",
                table: "COBActivity",
                column: "ContainerId");

            migrationBuilder.CreateIndex(
                name: "IX_COBActivity_StatusId",
                table: "COBActivity",
                column: "StatusId");

            migrationBuilder.CreateIndex(
                name: "IX_COBActivity_UserId",
                table: "COBActivity",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_DAPActivity_ContainerId",
                table: "DAPActivity",
                column: "ContainerId");

            migrationBuilder.CreateIndex(
                name: "IX_DAPActivity_HBLId",
                table: "DAPActivity",
                column: "HBLId");

            migrationBuilder.CreateIndex(
                name: "IX_DAPActivity_StatusId",
                table: "DAPActivity",
                column: "StatusId");

            migrationBuilder.CreateIndex(
                name: "IX_DAPActivity_UserId",
                table: "DAPActivity",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_DAPActvityHistory_ContainerId",
                table: "DAPActvityHistory",
                column: "ContainerId");

            migrationBuilder.CreateIndex(
                name: "IX_DAPActvityHistory_DapActivityId",
                table: "DAPActvityHistory",
                column: "DapActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_DAPActvityHistory_HBLId",
                table: "DAPActvityHistory",
                column: "HBLId");

            migrationBuilder.CreateIndex(
                name: "IX_DAPActvityHistory_StatusId",
                table: "DAPActvityHistory",
                column: "StatusId");

            migrationBuilder.CreateIndex(
                name: "IX_DAPActvityHistory_UserId",
                table: "DAPActvityHistory",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_FileAcitivityLogHistory_COBActivity_COBActivityId",
                table: "FileAcitivityLogHistory",
                column: "COBActivityId",
                principalTable: "COBActivity",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FileAcitivityLogHistory_COBActivity_COBActivityId",
                table: "FileAcitivityLogHistory");

            migrationBuilder.DropTable(
                name: "COBActivity");

            migrationBuilder.DropTable(
                name: "DAPActvityHistory");

            migrationBuilder.DropTable(
                name: "DAPActivity");

            migrationBuilder.DropIndex(
                name: "IX_FileAcitivityLogHistory_COBActivityId",
                table: "FileAcitivityLogHistory");

            migrationBuilder.DropColumn(
                name: "COBActivityId",
                table: "FileAcitivityLogHistory");
        }
    }
}
