﻿using CanadaExportTrackX.DataModel;

namespace CanadaExportTrackX.ViewModels
{
	public class UploadViewModel
	{
		public int CountryId { get; set; }
		public IFormFile File { get; set; }
	}
}
