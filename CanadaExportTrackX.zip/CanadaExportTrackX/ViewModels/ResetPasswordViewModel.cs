﻿using CanadaExportTrackX.DataModel;

namespace CanadaExportTrackX.ViewModels
{
    public class ResetPasswordViewModel
    {
        public IEnumerable<ApplicationUser> Users { get; set; }
        public string SelectedUserId { get; set; }
    }
}
