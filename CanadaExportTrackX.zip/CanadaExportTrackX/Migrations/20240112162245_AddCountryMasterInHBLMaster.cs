﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CanadaExportTrackX.Migrations
{
    public partial class AddCountryMasterInHBLMaster : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CountryId",
                table: "HBLMaster",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_HBLMaster_CountryId",
                table: "HBLMaster",
                column: "CountryId");

            migrationBuilder.AddForeignKey(
                name: "FK_HBLMaster_CountryMaster_CountryId",
                table: "HBLMaster",
                column: "CountryId",
                principalTable: "CountryMaster",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HBLMaster_CountryMaster_CountryId",
                table: "HBLMaster");

            migrationBuilder.DropIndex(
                name: "IX_HBLMaster_CountryId",
                table: "HBLMaster");

            migrationBuilder.DropColumn(
                name: "CountryId",
                table: "HBLMaster");
        }
    }
}
