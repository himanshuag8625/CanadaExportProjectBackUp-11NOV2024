﻿namespace CanadaExportTrackX.ViewModels
{
    public class ReportTemplateModel
    {
        public string? CountryName { get; set; }
        public string FileNumber { get; set; }
        public string? Container { get; set; }
        public string BookingNo { get; set; }
        public string HBL_No { get; set; }
        public DateTime? ETD { get; set; }
        public string ActivityId { get; set; }
        public string StatusId { get; set; }
        public string? Comment { get; set; }
        public string? UserId { get; set; } = null!;
        public DateTime? EnterDate { get; set; } 
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
