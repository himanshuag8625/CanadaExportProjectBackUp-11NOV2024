﻿namespace CanadaExportTrackX.ViewModels
{
    public class DAPActivityViewModel
    {
        public string Id { get; set; }
        public string? ContainerNo { get; set; }
        public string? FileNumber { get; set; }

        //public string HBLId { get; set; }
        public string? HBLId { get; set; }
        public string? HBLNumber { get; set; }
        public string? POD { get; set; }
        public string? Booking { get; set; }
        public DateTime? EnterDate { get; set; }
        public DateTime? VesselETA { get; set; }
        public string? VesselETADay { get; set; }
        public DateTime? FirstReminder { get; set; }
        public string? FirstReminderComment { get; set; }
        public string? FirstReminderStatus { get; set; }
        public DateTime? SecondReminder { get; set; }
        public string? SecondReminderComment { get; set; }
        public string? SecondReminderStatus { get; set; }
        public DateTime? ThirdReminder { get; set; }
        public string? ThirdReminderComment { get; set; }
        public string? ThirdReminderStatus { get; set; }
        public string? StatusId { get; set; }
        public string? UserId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
