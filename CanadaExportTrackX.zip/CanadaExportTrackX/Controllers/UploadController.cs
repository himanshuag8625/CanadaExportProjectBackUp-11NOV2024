﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Drawing;
using System.Net;
using CanadaExportTrackX;
using Microsoft.AspNetCore.Authorization;
using CanadaExportTrackX.DataModel;
using CanadaExportTrackX.ViewModels;
using CanadaExportTrackX;

namespace CanadaExportTrackX.Controllers
{
    public class UploadController : Controller
    {
        ApplicationDBContext _context;
        public UploadController(ApplicationDBContext context)
        {
            _context = context;

        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public IActionResult Index()
        {
            ViewData["Countries"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return View(new UploadViewModel());
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpPost]
        public async Task<IActionResult> Index(UploadViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Save the uploaded file to the server
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", model.File.FileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await model.File.CopyToAsync(stream);
                }
                var uploadResult = UploadFile(filePath);

                // Check if the UploadFile method was successful
                if (uploadResult is JsonResult && ((JsonResult)uploadResult).Value.ToString() == "success")
                {
                    return Json("success");
                }
                else
                {
                    return Json("error");
                }
            }
            else
            {
                return Json("Invalid file.");
            }
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult UploadFile(string filePath)
        {
            DataTable Rawdata = new DataTable();
            List<FileMaster> filemaster = new List<FileMaster>();
            List<HBLMaster> hBLMaster = new List<HBLMaster>();
            List<FileActivityLog> fileActivityLog = new List<FileActivityLog>();
            var carrierRequest = _context.ActivityMaster.FirstOrDefault(x => x.NameOfActivity == "Carrier Request" && x.IsActive == true && x.IsDelete == false)?.Id;
            var pending = _context.StatusMaster.FirstOrDefault(x => x.Status == "Pending" && x.IsActive == true && x.IsDelete == false)?.Id;
            DataTable UploadRawdata = GeneralFunction.GetDataFromExcel(filePath);
            var isfilepresent = _context.FileMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            try
            {
                var filemasterdata = UploadRawdata.AsEnumerable().ToList();

                foreach (DataRow dr in filemasterdata)
                {
                    string fileNumber = dr["File Number"].ToString().Trim();
                    string[] parts = fileNumber.Split('/');
                    string countryName = parts[1];
                    var duplicate = isfilepresent.FirstOrDefault(x => x.FileNumber == fileNumber);
                    var countryId = _context.CountryMaster
                        .FirstOrDefault(x => x.CountryName == countryName && x.IsActive == true && x.IsDelete == false)?.Id;

                    if (duplicate == null)
                    {
                        try
                        {
                            FileMaster filemas = InsertIntoDB(dr, countryName, countryId);
                            filemaster.Add(filemas);
                        }
                        catch (Exception ex)
                        {
                            return Json("error");
                        }
                    }
                    else
                    {
                        try
                        {
                            UpdateFileMaster(duplicate, dr, countryId);
                        }
                        catch (Exception ex)
                        {
                            return Json("error");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("error");
            }

            _context.FileMaster.AddRange(filemaster);
            _context.SaveChanges();

            var fileList = _context.FileMaster.ToList();

            foreach (var file in fileList)
            {
                var container = _context.ContainerMaster.FirstOrDefault(x => x.FileMaster.FileNumber == file.FileNumber);

                if (container == null)
                {
                    _context.ContainerMaster.Add(new ContainerMaster
                    {
                        FileId = file.Id,
                        ContainerNo = null
                    });
                }
                else
                {
                    container.FileId = file.Id;
                    container.ContainerNo = container.ContainerNo;
                }

                _context.SaveChanges();
            }

            var containers = _context.ContainerMaster.ToList();

            foreach (var item in containers)
            {
                var filelog = _context.FileActivityLog.FirstOrDefault(x => x.ContainerMaster.ContainerNo == item.ContainerNo);

                if (filelog == null)
                {
                    fileActivityLog.Add(new FileActivityLog
                    {
                        ContainerId = item.Id,
                        ActivityId = carrierRequest,
                    });
                }
                else
                {
                    filelog.ContainerId = item.Id;
                    filelog.ActivityId = filelog.ActivityId;
                    _context.FileActivityLog.Update(filelog);
                    _context.SaveChanges();
                }
            }

            _context.FileActivityLog.AddRange(fileActivityLog);
            _context.SaveChanges();

            return Json("success");
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public FileMaster InsertIntoDB(DataRow dr, string countryName, string countryId)
        {
            var country = _context.CountryMaster.FirstOrDefault(x => x.CountryName == countryName && x.IsActive == true && x.IsDelete == false);

            if (country == null)
            {
                country = new CountryMaster
                {
                    CountryName = countryName
                };

                _context.CountryMaster.Add(country);
                _context.SaveChanges();
            }
            else
            {
                country.CountryName = countryName;
            }

            var efile = new FileMaster
            {
                Id = Guid.NewGuid().ToString(),
                FileNumber = dr["File Number"].ToString().Trim(),
                FileType = dr["Produ"].ToString().Trim(),
                POD = country.Id,
                TotalBL = Convert.ToInt32(dr["No of B"].ToString().Trim()),
                ShippingLine = dr["Shipping Agent"].ToString().Trim(),
                FileContact = dr["File Conta"].ToString().Trim(),
                MBL = dr["Agent Ref"].ToString().Trim(),
                Vessel = dr["Vessel"].ToString().Trim(),
                Voyage = dr["Voyage"].ToString().Trim(),
                ETA = string.IsNullOrEmpty(dr["ETA Origin"].ToString()) ? null : (DateTime?)Convert.ToDateTime(dr["ETA Origin"]),
                ETD = string.IsNullOrEmpty(dr["ETD Origin"].ToString()) ? null : (DateTime?)Convert.ToDateTime(dr["ETD Origin"]),
                ETAPOD = string.IsNullOrEmpty(dr["ETA Hub"].ToString()) ? null : (DateTime?)Convert.ToDateTime(dr["ETA Hub"]),
                FileRemark = dr["File Remark"].ToString().Trim(),
                Coload = dr["Coload"].ToString().Trim(),
                EnterDate = DateTime.UtcNow,
            };

            return efile;
        }

        private void UpdateFileMaster(FileMaster duplicate, DataRow dr, string countryId)
        {
            duplicate.FileNumber = dr["File Number"].ToString().Trim();
            duplicate.FileType = dr["Produ"].ToString().Trim();
            duplicate.POD = countryId;
            duplicate.TotalBL = Convert.ToInt32(dr["No of B"].ToString().Trim());
            duplicate.ShippingLine = dr["Shipping Agent"].ToString().Trim();
            duplicate.FileContact = dr["File Conta"].ToString().Trim();
            duplicate.MBL = dr["Agent Ref"].ToString().Trim();
            duplicate.Vessel = dr["Vessel"].ToString().Trim();
            duplicate.Voyage = dr["Voyage"].ToString().Trim();
            duplicate.ETA = string.IsNullOrEmpty(dr["ETA Origin"].ToString()) ? null : (DateTime?)Convert.ToDateTime(dr["ETA Origin"]);
            duplicate.ETD = string.IsNullOrEmpty(dr["ETD Origin"].ToString()) ? null : (DateTime?)Convert.ToDateTime(dr["ETD Origin"]);
            duplicate.ETAPOD = string.IsNullOrEmpty(dr["ETA Hub"].ToString()) ? null : (DateTime?)Convert.ToDateTime(dr["ETA Hub"]);
            duplicate.FileRemark = dr["File Remark"].ToString().Trim();
            duplicate.Coload = dr["Coload"].ToString().Trim();
            duplicate.EnterDate = DateTime.UtcNow;

            _context.FileMaster.Update(duplicate);
        }
    }
}
