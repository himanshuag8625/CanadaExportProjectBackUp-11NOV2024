﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CanadaExportTrackX.Migrations
{
    public partial class HBLLogIdInHBLHistory : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HBLActivitylogHistory_HBLActivityLog_HblLogId",
                table: "HBLActivitylogHistory");

            // Drop the existing index before altering the column
            migrationBuilder.DropIndex(
                name: "IX_HBLActivitylogHistory_HBLLogId",
                table: "HBLActivitylogHistory");

            migrationBuilder.DropColumn(
                name: "HBLogId",
                table: "HBLActivitylogHistory");

            migrationBuilder.RenameColumn(
                name: "HblLogId",
                table: "HBLActivitylogHistory",
                newName: "HBLLogId");

            migrationBuilder.AlterColumn<string>(
                name: "HBLLogId",
                table: "HBLActivitylogHistory",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            // Recreate the index after the column alteration
            migrationBuilder.CreateIndex(
                name: "IX_HBLActivitylogHistory_HBLLogId",
                table: "HBLActivitylogHistory",
                column: "HBLLogId");

            migrationBuilder.AddForeignKey(
                name: "FK_HBLActivitylogHistory_HBLActivityLog_HBLLogId",
                table: "HBLActivitylogHistory",
                column: "HBLLogId",
                principalTable: "HBLActivityLog",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict); // Changed to Restrict or NoAction
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HBLActivitylogHistory_HBLActivityLog_HBLLogId",
                table: "HBLActivitylogHistory");

            // Drop the index before reverting the column alteration
            migrationBuilder.DropIndex(
                name: "IX_HBLActivitylogHistory_HBLLogId",
                table: "HBLActivitylogHistory");

            migrationBuilder.RenameColumn(
                name: "HBLLogId",
                table: "HBLActivitylogHistory",
                newName: "HblLogId");

            migrationBuilder.AlterColumn<string>(
                name: "HblLogId",
                table: "HBLActivitylogHistory",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: false);

            // Recreate the index after reverting the column alteration
            migrationBuilder.CreateIndex(
                name: "IX_HBLActivitylogHistory_HblLogId",
                table: "HBLActivitylogHistory",
                column: "HblLogId");

            migrationBuilder.AddColumn<string>(
                name: "HBLogId",
                table: "HBLActivitylogHistory",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddForeignKey(
                name: "FK_HBLActivitylogHistory_HBLActivityLog_HblLogId",
                table: "HBLActivitylogHistory",
                column: "HblLogId",
                principalTable: "HBLActivityLog",
                principalColumn: "Id");
        }
    }
}
