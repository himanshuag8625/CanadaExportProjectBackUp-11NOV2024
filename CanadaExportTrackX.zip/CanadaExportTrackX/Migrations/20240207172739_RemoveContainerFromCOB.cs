﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CanadaExportTrackX.Migrations
{
    public partial class RemoveContainerFromCOB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_COBActivity_ContainerMaster_ContainerId",
                table: "COBActivity");

            migrationBuilder.DropIndex(
                name: "IX_COBActivity_ContainerId",
                table: "COBActivity");

            migrationBuilder.DropColumn(
                name: "ContainerId",
                table: "COBActivity");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ContainerId",
                table: "COBActivity",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_COBActivity_ContainerId",
                table: "COBActivity",
                column: "ContainerId");

            migrationBuilder.AddForeignKey(
                name: "FK_COBActivity_ContainerMaster_ContainerId",
                table: "COBActivity",
                column: "ContainerId",
                principalTable: "ContainerMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
