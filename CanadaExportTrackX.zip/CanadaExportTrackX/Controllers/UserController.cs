﻿using CanadaExportTrackX.DataModel;
using CanadaExportTrackX.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Linq.Dynamic.Core;
using Microsoft.AspNetCore.Authorization;
using System.Globalization;
using DocumentFormat.OpenXml.Drawing.Charts;

namespace CanadaExportTrackX.Controllers
{
    [Authorize]
    public class UserController : Controller
    {
        ApplicationDBContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public UserController(ApplicationDBContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }
        public IActionResult Index(string ActivityId)
        {
            var country = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            var activity = _context.ActivityMaster.Where(x => x.Id == ActivityId && x.IsDelete == false && x.IsActive == true).FirstOrDefault();

            if (activity.ActivityType == "File")
            {
                activity.NameOfActivity += " (F)";
            }
            else
            {
                activity.NameOfActivity += " (H)";
            }

            ViewBag.Country = country;
            ViewBag.Activity = activity;
            return View();
        }

        public IActionResult Files(string activityId)
        {
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.Id == activityId && x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetFiles(string country, string fileNumber, string activity, string search, string type)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            DateTime date = DateTime.UtcNow;
            DateTime threeMonth = DateTime.UtcNow.AddMonths(-3);

            var fileData = _context.ContainerMaster.Where(x => x.SICutOff >= threeMonth.Date || x.SICutOff == null)
                .Include(x => x.FileMaster)
                .Include(x => x.FileActivityLogs)
                    .ThenInclude(x => x.ApplicationUser)
                .Select(a => new FileDashModel
                {
                    Id = a.FileMaster.Id,
                    FileLogId = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id)
                        .Select(y => y.Id)
                        .FirstOrDefault(),
                    EnterDate = a.FileMaster.EnterDate,
                    FileNumber = a.FileMaster.FileNumber.Substring(0, a.FileMaster.FileNumber.Length - 6),
                    POD = a.FileMaster.CountryMaster.CountryName,
                    ETD = a.FileMaster.ETD,
                    ETAPOD = a.FileMaster.ETAPOD,
                    ETA = a.FileMaster.ETA,
                    ATD = a.FileMaster.ATD,
                    SICutOff = a.SICutOff,
                    ShippingLine = a.FileMaster.ShippingLine,
                    FileContact = a.FileMaster.FileContact,
                    UserId = a.FileActivityLogs.Where(y => y.ContainerId == a.Id).FirstOrDefault().ApplicationUser.UserName ?? "",
                    StatusId = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id).OrderBy(x => x.EndDate)
                            .FirstOrDefault().Status.Status ?? "UnAllocated",
                    StatusCompleted = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id)
                            .FirstOrDefault().EndDate,
                    ActivityId = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id).OrderBy(x => x.EndDate)
                            .FirstOrDefault().Activity.NameOfActivity ?? "",
                    ActivityType = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id)
                            .FirstOrDefault().Activity.ActivityType ?? "",
                    ContainerNo = a.ContainerNo,
                    ContainerId = a.Id,
                    //TotalHBL = a.FileMaster.TotalBL,
                    Comment = a.FileActivityLogs
                            .Where(y => y.ContainerId == a.Id)
                           .FirstOrDefault().Comment,
                    Roe = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Roe != null)
                        .FirstOrDefault().Roe,
                    CurrentUser = userName,
                    EndDate = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id)
                        .FirstOrDefault().EndDate,
                    CarrierBookingsId = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Carrier Bookings")
                        .FirstOrDefault().Status.Status ?? "UnAllocated",
                    CarrierBookingsCompleted = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Carrier Bookings")
                        .FirstOrDefault().EndDate,
                    PresailingId = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Sailing Schedule/Pre-sailing")
                        .FirstOrDefault().Status.Status ?? "UnAllocated",
                    PresailingCompleted = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Sailing Schedule/Pre-sailing")
                        .FirstOrDefault().EndDate,
                    VesselChangeId = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Vessel Change/Delay Notices")
                        .FirstOrDefault().Status.Status ?? "UnAllocated",
                    VesselChangeCompleted = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Vessel Change/Delay Notices")
                        .FirstOrDefault().EndDate,
                    SIRequesttoShipperId = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "SI Request to Shipper/Follow ups")
                        .FirstOrDefault().Status.Status ?? "UnAllocated",
                    SIRequesttoShipperCompleted = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "SI Request to Shipper/Follow ups")
                        .FirstOrDefault().EndDate,
                    SIToCarrier = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "SI To Carrier")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    SIToCarrierCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "SI To Carrier")
                    .FirstOrDefault().EndDate,
                    TallySheetComment = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "Tally Sheet")
                        .FirstOrDefault().Comment ?? "",
                    MblReviewComment = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "MBL Review")
                        .FirstOrDefault().Comment ?? "",
                    TblProcessingComment = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "TBL Processing")
                        .FirstOrDefault().Comment ?? "",
                    BLRequestComment = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
                        .FirstOrDefault().Comment ?? "",
                    MBLReviewId = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "MBL Review/Amendment")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    MBLReviewCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "MBL Review/Amendment")
                    .FirstOrDefault().EndDate,
                    BLRequest = a.FileActivityLogs
                        .Where(y => y.ContainerId == a.Id && y.Activity.NameOfActivity == "BL Request")
                        .FirstOrDefault().Status.Status ?? "UnAllocated",
                    BondProcessingId = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Bond Processing (Canada)")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    BondProcessingCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Bond Processing (Canada)")
                    .FirstOrDefault().EndDate,
                    EDIId = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "EDI")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    EDICompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "EDI")
                    .FirstOrDefault().EndDate,
                    PreAlerttoPODId = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Pre-Alert to POD")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    PreAlerttoPODCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Pre-Alert to POD")
                    .FirstOrDefault().EndDate,
                    ShippingConfirmationId = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Shipping Confirmation")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    ShippingConfirmationCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Shipping Confirmation")
                    .FirstOrDefault().EndDate,
                    DAPId = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "DAP")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    DAPCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "DAP")
                    .FirstOrDefault().EndDate,
                    Permit = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Permit")
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                    PermitCompleted = a.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Permit")
                    .FirstOrDefault().EndDate,
                    LBL = a.HBLMasters.Where(y => y.ContainerId == a.Id && y.HBLNumber.StartsWith("SIN")).Count(),
                    TBL = a.HBLMasters.Where(y => y.ContainerId == a.Id && !y.HBLNumber.StartsWith("SIN")).Count(),
                    TotalHBL = a.HBLMasters.Where(y => y.ContainerId == a.Id).Count() != 0 ? (a.HBLMasters.Where(y => y.ContainerId == a.Id && y.HBLNumber.StartsWith("SIN")).Count()) + (a.HBLMasters.Where(y => y.ContainerId == a.Id && !y.HBLNumber.StartsWith("SIN")).Count()) : a.FileMaster.TotalBL
                }).AsQueryable();

            IQueryable<FileDashModel> data = fileData.AsQueryable();
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
            }
            if (date != null)
            {
                data = data.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff == null);
            }
            if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
            {
                data = data.Where(x => x.POD == country);
            }
            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (activity == "SI To Carrier")
            {
                sortColumn = "siCutOff";
                data = data.OrderBy(sortColumn + " " + sortColumnDirection);
            }
            else if (activity == "Final BL To Invoices  Customer")
            {
                sortColumn = "etd";
                data = data.OrderBy(sortColumn + " " + sortColumnDirection);
            }
            else
            {
                sortColumn = "enterDate";
                data = data.OrderBy(sortColumn + " " + sortColumnDirection);
            }

            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);

            data = data.Select(a => new FileDashModel
            {
                Id = a.Id,
                FileLogId = a.FileLogId,
                EnterDate = a.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.EnterDate.Value, istTimeZone) : (DateTime?)null,
                FileNumber = a.FileNumber,
                POD = a.POD,
                ETD = a.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ETD.Value, istTimeZone) : (DateTime?)null,
                ETAPOD = a.ETAPOD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ETAPOD.Value, istTimeZone) : (DateTime?)null,
                ETA = a.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ETA.Value, istTimeZone) : (DateTime?)null,
                ATD = a.ATD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ATD.Value, istTimeZone) : (DateTime?)null,
                SICutOff = a.SICutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.SICutOff.Value, istTimeZone) : (DateTime?)null,
                ShippingLine = a.ShippingLine,
                FileContact = a.FileContact,
                UserId = a.UserId,
                StatusId = a.StatusId,
                StatusCompleted = a.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.EnterDate.Value, istTimeZone) : (DateTime?)null,
                ActivityId = a.ActivityId,
                ActivityType = a.ActivityType,
                ContainerNo = a.ContainerNo,
                ContainerId = a.ContainerId,
                Comment = a.Comment,
                Roe = a.Roe,
                CurrentUser = a.CurrentUser,
                EndDate = a.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.EndDate.Value, istTimeZone) : (DateTime?)null,
                CarrierBookingsId = a.CarrierBookingsId,
                CarrierBookingsCompleted = a.CarrierBookingsCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.CarrierBookingsCompleted.Value, istTimeZone) : (DateTime?)null,
                PresailingId = a.PresailingId,
                PresailingCompleted = a.PresailingCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.PresailingCompleted.Value, istTimeZone) : (DateTime?)null,
                VesselChangeId = a.VesselChangeId,
                VesselChangeCompleted = a.VesselChangeCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.VesselChangeCompleted.Value, istTimeZone) : (DateTime?)null,
                SIRequesttoShipperId = a.SIRequesttoShipperId,
                SIRequesttoShipperCompleted = a.SIRequesttoShipperCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.SIRequesttoShipperCompleted.Value, istTimeZone) : (DateTime?)null,
                TallySheetComment = a.TallySheetComment,
                MblReviewComment = a.MblReviewComment,
                TblProcessingComment = a.TblProcessingComment,
                BLRequestComment = a.BLRequestComment,
                CarrierRequest = a.CarrierRequest,
                CarrierRequestCompleted = a.CarrierRequestCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.CarrierRequestCompleted.Value, istTimeZone) : (DateTime?)null,
                BLRequest = a.BLRequest,
                MBLReviewId = a.MBLReviewId,
                MBLReviewCompleted = a.MBLReviewCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.MBLReviewCompleted.Value, istTimeZone) : (DateTime?)null,
                BondProcessingId = a.BondProcessingId,
                BondProcessingCompleted = a.BondProcessingCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.BondProcessingCompleted.Value, istTimeZone) : (DateTime?)null,
                SIToCarrier = a.SIToCarrier,
                SIToCarrierCompleted = a.SIToCarrierCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.SIToCarrierCompleted.Value, istTimeZone) : (DateTime?)null,
                EDIId = a.EDIId,
                EDICompleted = a.EDICompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.EDICompleted.Value, istTimeZone) : (DateTime?)null,
                PreAlerttoPODId = a.PreAlerttoPODId,
                PreAlerttoPODCompleted = a.PreAlerttoPODCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.PreAlerttoPODCompleted.Value, istTimeZone) : (DateTime?)null,
                ShippingConfirmationId = a.ShippingConfirmationId,
                ShippingConfirmationCompleted = a.ShippingConfirmationCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.ShippingConfirmationCompleted.Value, istTimeZone) : (DateTime?)null,
                DAPId = a.DAPId,
                DAPCompleted = a.DAPCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.DAPCompleted.Value, istTimeZone) : (DateTime?)null,
                Permit = a.Permit,
                PermitCompleted = a.PermitCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(a.PermitCompleted.Value, istTimeZone) : (DateTime?)null,
                LBL = a.LBL,
                TBL = a.TBL,
                TotalHBL = a.TotalHBL
            }).AsQueryable();

            var files = data.ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = fileData.Count(),
                recordsFiltered = files.Count(),
                data = files
            });
        }

        [HttpGet]
        public IActionResult GetHblActivityData(string hblnumber)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.Status).Where(x => x.Hbl.HBLNumber == hblnumber).ToList();
            IQueryable<HBLActivityLog> hblActivityLog = hblact.AsQueryable();
            foreach (var item in hblact)
            {
                hblActivityLog.Select(x => new HBLActivityLog
                {
                    ActivityId = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    StatusId = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
                    UserId = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                }).ToList();
            }
            return Json(hblact);
        }

        [HttpGet]
        public IActionResult HBL(string activityId, string fileNumber)
        {
            ViewData["CountryId"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.Id == activityId && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetHBLs(string country, string fileNumber, string activity, string search, string type)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            var hblData = _context.HBLMaster
                .Include(x => x.CountryMaster)
                .Include(x => x.HBLActivityLogs)
                .Include(x => x.ContainerMaster)
                .Select(x => new HBLDashViewModel
                {
                    Id = x.Id,
                    HBLNumber = x.HBLNumber,
                    FileId = x.Id,
                    EnterDate = x.EnterDate,
                    POD = x.CountryMaster.CountryName,
                    FileNumber = x.ContainerMaster.FileMaster.FileNumber.Substring(0, x.ContainerMaster.FileMaster.FileNumber.Length - 6),
                    ContainerNo = x.ContainerMaster.ContainerNo,
                    BookingNo = x.Booking,
                    CustomerName = x.CustomerName,
                    CurrentUser = userid,
                    Activity = x.HBLActivityLogs.OrderByDescending(y => y.EndDate).Select(y => y.Activity.NameOfActivity).FirstOrDefault() ?? "",
                    EmailReceivedDate = x.HBLActivityLogs.OrderByDescending(y => y.EndDate).Select(y => y.EmailReceivedDate).FirstOrDefault() ?? (DateTime?)null,
                    ActivityType = x.HBLActivityLogs.OrderByDescending(y => y.EndDate).Select(y => y.Activity.ActivityType).FirstOrDefault() ?? "",
                    User = x.HBLActivityLogs.OrderByDescending(y => y.EndDate).Select(y => y.ApplicationUser.UserName).FirstOrDefault() ?? "",
                    Status = x.HBLActivityLogs.OrderByDescending(y => y.EndDate).Select(y => y.Status.Status).FirstOrDefault() ?? "UnAllocated",
                    Comment = x.HBLActivityLogs.OrderByDescending(y => y.EndDate).Select(y => y.Comment).FirstOrDefault() ?? "",
                    StartDate = x.HBLActivityLogs.OrderByDescending(y => y.EndDate).Select(y => y.StartDate).FirstOrDefault(),
                    EndDate = x.HBLActivityLogs.OrderByDescending(y => y.EndDate).Select(y => y.EndDate).FirstOrDefault()
                }).AsQueryable();

            IQueryable<HBLDashViewModel> data = hblData.AsQueryable();

            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber));
            }
            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                data = data.Where(x => string.IsNullOrEmpty(x.Activity) && string.IsNullOrEmpty(x.ActivityType) || x.Activity != activity && x.ActivityType != type);
            }
            if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
            {
                data = data.Where(x => x.POD == country);
            }
            if (string.IsNullOrEmpty(sortColumn))
            {
                sortColumn = "hblNumber";
            }

            var files = data.OrderBy(sortColumn + " " + sortColumnDirection).ToList();
                        const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);

            files = files.Select(x => new HBLDashViewModel
            {
                Id = x.Id,
                HBLNumber = x.HBLNumber,
                FileId = x.Id,
                EnterDate = x.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EnterDate.Value, istTimeZone) : (DateTime?)null,
                POD = x.POD,
                FileNumber = x.FileNumber,
                ContainerNo = x.ContainerNo,
                BookingNo = x.BookingNo,
                CustomerName = x.CustomerName,
                CurrentUser = x.CurrentUser,
                Activity = x.Activity,
                EmailReceivedDate = x.EmailReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EmailReceivedDate.Value, istTimeZone) : (DateTime?)null,
                ActivityType = x.ActivityType,
                User = x.User,
                Status = x.Status,
                Comment = x.Comment,
                StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
            }).ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = hblData.Count(),
                recordsFiltered = files.Count(),
                data = files
            });
        }

        [HttpGet]
        public IActionResult GetFileActivityData(string Id)
        {
            var adhocFile = _context.AdhocFileActivityLog.Where(fileActivity => fileActivity.AdhocFile.Id == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();

            return Json(new { adhocFile });
        }

        [HttpGet]
        public IActionResult GetHBLActivityData(string Id)
        {
            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);

            var adhocHBL = _context.AdhocHBLActivityLog.Where(fileActivity => fileActivity.AdhocHBLId == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {
                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();

            adhocHBL = adhocHBL.Select(x => new
            {
                Id = x.Id,
                ActivityName = x.ActivityName,
                Status = x.Status,
                ProcessedDate = x.ProcessedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ProcessedDate.Value, istTimeZone) : (DateTime?)null,
                User = x.User,
                Comment = x.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();

            return Json(new { adhocHBL });
        }

        [HttpGet]
        public IActionResult GetHBLActivity(string Id)
        {
            var HBL = _context.HBLActivityLog.Where(x => x.HBLId == Id)
            .Include(activity => activity.Activity)
            .Include(status => status.Status)
            .Include(user => user.ApplicationUser)
            .Select(x => new
            {
                Id = x.Activity.Id,
                ActivityName = x.Activity.NameOfActivity == null ? "" : x.Activity.NameOfActivity,
                EmailReceivedDate = x.EmailReceivedDate.HasValue ? x.EmailReceivedDate : (DateTime?)null,
                Status = x.Status.Status == null ? "" : x.Status.Status,
                ProcessedDate = x.EndDate.HasValue ? x.EndDate : (DateTime?)null,
                User = x.ApplicationUser.UserName == null ? "" : x.ApplicationUser.CitrixId,
                Comment = x.Comment == null ? "" : x.Comment,
            })
           .OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable().ToList();

            return Json(new { HBL });
        }

        [HttpGet]
        public IActionResult GetHblActivitiesData(string hblId)
        {
            ViewData["hblActivityList"] = _context.HBLActivityLog.Where(x => x.HBLId == hblId).Select(x => new HBLActivityLogViewModel
            {
                HBLId = x.HBLId,
                HBLNumber = x.Hbl.HBLNumber == null ? "" : x.Hbl.HBLNumber,
                ActivityId = x.Activity.NameOfActivity,
                EndDate = x.EndDate,
                StatusId = x.Status.Status,
                Comment = x.Comment == null ? "" : x.Comment,
                UserId = x.ApplicationUser.CitrixId == null ? "" : x.ApplicationUser.CitrixId
            }).ToList();

            return PartialView();
        }

        [HttpPost]
        public IActionResult GetHblActivitiesData(string hblno, string hbl)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.ApplicationUser).Where(x => x.Hbl.HBLNumber == hblno).ToList();
            List<HBLActivityLogViewModel> hblActivityLog = new List<HBLActivityLogViewModel>();
            foreach (var item in hblact)
            {
                hblActivityLog.Add(new HBLActivityLogViewModel
                {
                    HBLNumber = hblno == null ? "" : hblno,
                    ActivityId = item.Activity.NameOfActivity == null ? "" : item.Activity.NameOfActivity,
                    EndDate = item.EndDate,
                    StatusId = item.Status.Status,
                    UserId = item.ApplicationUser.CitrixId,
                });
            }

            return Json(hblActivityLog);
        }

        [HttpPost]
        public JsonResult AddHBLActivities(HBLActivityLogViewModel model, string button, string? statusValue, string? startDateValue, string? endDateValue, string? hblComments, string? activityValue, DateTime? emailReceiveDateValue)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            var editData = _context.HBLActivityLog.FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == model.ActivityId);
            var wip = _context.StatusMaster.FirstOrDefault(x => x.Status == "WIP" && x.IsActive == true && x.IsDelete == false);
            var statusList = _context.StatusMaster.FirstOrDefault(x => x.Status == statusValue && x.IsActive == true && x.IsDelete == false);
            var hblList = _context.HBLActivityLog.FirstOrDefault(x => x.HBLId == model.HBLId);
            var userList = _context.Users.FirstOrDefault(x => x.UserName == model.UserId && x.IsActive == true && x.IsDelete == false);
            string? userId = (userList != null) ? userList?.Id : null;
            string? selectedStatusId = (statusValue != "UnAllocated") ? statusList?.Id : null;

            if (button == "Edit")
            {
                if (ModelState.IsValid)
                {
                    var hblactivityList = _context.HBLActivityLog.FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == model.ActivityId);

                    if (activityValue != null)
                    {
                        var activtyList = _context.ActivityMaster.Where(x => x.NameOfActivity == activityValue && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
                        hblactivityList = _context.HBLActivityLog.Include(x => x.Status).Include(x => x.Hbl).FirstOrDefault(x => x.HBLId == model.HBLId);
                        if (hblactivityList != null && hblactivityList.Status.Status != "Completed")
                        {
                            if (editData != null && model.StatusId != wip.Status)
                            {
                                hblList.HBLId = model.HBLId;
                                hblList.ActivityId = hblactivityList.ActivityId;
                                hblList.StatusId = wip.Id;
                                hblList.UserId = userid;
                                hblList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                _context.HBLActivityLog.Update(hblList);
                            }
                            else if (editData != null && model.StatusId == wip.Status && editData.UserId == userid)
                            {
                                hblList.HBLId = model.HBLId;
                                hblList.ActivityId = hblactivityList.ActivityId;
                                hblList.StatusId = wip.Id;
                                hblList.UserId = userid;
                                hblList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                _context.HBLActivityLog.Update(hblList);
                            }
                            else
                            {
                                return Json("Activity is processed by other user");
                            }
                        }
                    }
                    else
                    {
                        _context.HBLActivityLog.Add(new HBLActivityLog
                        {
                            HBLId = model.HBLId,
                            ActivityId = model.ActivityId,
                            StatusId = wip.Id,
                            UserId = userid,
                            StartDate = null,
                            EndDate = null,
                            Comment = null
                        });
                    }

                    _context.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else if (button == "Cancel")
            {
                if (ModelState.IsValid)
                {
                    if (editData != null)
                    {
                        hblList.HBLId = model.HBLId;
                        hblList.ActivityId = model.ActivityId;
                        hblList.StatusId = selectedStatusId;
                        hblList.UserId = userId;
                        _context.HBLActivityLog.Update(hblList);
                    }
                    _context.SaveChanges();

                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else
            {
                if (ModelState.IsValid)
                {
                    var activityListData = _context.HBLActivityLog.FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == model.ActivityId);
                    if (activityListData != null)
                    {
                        _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
                        {
                            HblLogId = activityListData.Id,
                            ActivityId = activityListData.ActivityId != null ? activityListData.ActivityId : null,
                            EmailReceiveDate = activityListData.EmailReceivedDate == null ? (DateTime?)null : activityListData.EmailReceivedDate,
                            StatusId = activityListData.StatusId != null ? activityListData.StatusId : null,
                            UserId = activityListData.UserId != null ? activityListData.UserId : null,
                            StartDate = activityListData.StartDate != null ? activityListData.StartDate : (DateTime?)null,
                            EndDate = activityListData.EndDate != null ? activityListData.EndDate : (DateTime?)null,
                            Comment = activityListData.Comment != null ? activityListData.Comment : null
                        });

                        var hblLog = _context.HBLActivityLog.FirstOrDefault(x => x.Id == activityListData.Id && x.ActivityId == model.ActivityId);
                        if (hblLog != null)
                        {
                            hblLog.ActivityId = model.ActivityId;
                            hblLog.EmailReceivedDate = model.EmailReceiveDate != null ? Convert.ToDateTime(model.EmailReceiveDate).ToUniversalTime() : (DateTime?)null;
                            hblLog.StatusId = model.StatusId;
                            hblLog.UserId = userid;
                            hblLog.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                            hblLog.EndDate = DateTime.UtcNow;
                            hblLog.Comment = model.Comment;
                            _context.HBLActivityLog.Update(hblLog);
                        }
                    }
                    else
                    {
                        //_context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
                        //{
                        //    HblLogId = activityListData.Id,
                        //    ActivityId = activityListData.ActivityId != null ? activityListData.ActivityId : null,
                        //    EmailReceiveDate = activityListData.EmailReceivedDate == null ? (DateTime?)null : activityListData.EmailReceivedDate,
                        //    StatusId = activityListData.StatusId != null ? activityListData.StatusId : null,
                        //    UserId = activityListData.UserId != null ? activityListData.UserId : null,
                        //    StartDate = activityListData.StartDate != null ? activityListData.StartDate : (DateTime?)null,
                        //    EndDate = activityListData.EndDate != null ? activityListData.EndDate : (DateTime?)null,
                        //    Comment = activityListData.Comment != null ? activityListData.Comment : null
                        //});

                        var activityData = _context.HBLActivityLog.FirstOrDefault(x => x.HBLId == model.HBLId && x.ActivityId == model.ActivityId);

                        _context.HBLActivityLog.Add(new HBLActivityLog
                        {
                            HBLId = model.HBLId,
                            ActivityId = model.ActivityId,
                            EmailReceivedDate = model.EmailReceiveDate != null ? Convert.ToDateTime(model.EmailReceiveDate).ToUniversalTime() : (DateTime?)null,
                            StatusId = model.StatusId,
                            UserId = userid,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = DateTime.UtcNow,
                            Comment = model.Comment
                        });
                    }

                    _context.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
        }

        [HttpGet]
        public IActionResult CreateFile()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewBag.Status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult AddFileNewActivity(FileAddActivityLogModel file)
        {
            if (ModelState.IsValid)
            {
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                FileMaster fileMaster = _context.FileMaster.FirstOrDefault(x => x.FileNumber.ToUpper().Contains(file.FileNumber.ToUpper().Trim()));
                var currentDate = DateTime.Now;
                DateTime ETD = Convert.ToDateTime(file.ETD);
                DateTime ETA = Convert.ToDateTime(file.ETA);
                DateTime ETAPOD = Convert.ToDateTime(file.ETAPOD);
                DateTime ATD = Convert.ToDateTime(file.ATD);
                var carrierRequest = _context.ActivityMaster.FirstOrDefault(x => x.FileSequence == 1 && x.IsActive == true && x.IsDelete == false);
                var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
                var Msg = "";
                if (role == "User")
                {
                    if (fileMaster == null)
                    {
                        fileMaster = new FileMaster
                        {
                            POD = file.CountryId,       
                            FileNumber = file.FileNumber.ToUpper().Trim(),
                            ETD = ETD,
                            ShippingAgent = file.ShippingAgent,
                            ShippingLine = file.ShippingLine,
                            FileContact = file.FileContact,
                            TotalBL = file.TotalHBL,
                            ETA = ETA,
                            ETAPOD = ETAPOD,
                            ATD = ATD,
                            EnterDate = DateTime.UtcNow,
                            IsActive = true,
                            IsDelete = false
                        };
                        _context.FileMaster.Add(fileMaster);

                        var fileContainer = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id);
                        var containermaster = _context.ContainerMaster.Where(x => x.FileId == fileMaster.Id && x.ContainerNo == file.Container).FirstOrDefault();

                        if (containermaster != null)
                        {
                            containermaster.FileId = fileMaster.Id;
                            containermaster.ContainerNo = file.Container;
                            _context.ContainerMaster.Update(containermaster);
                        }
                        else
                        {
                            if (fileContainer != null)
                            {
                                fileContainer.FileId = fileMaster.Id;
                                fileContainer.ContainerNo = file.Container;
                                _context.ContainerMaster.Update(fileContainer);
                            }
                            else
                            {
                                _context.ContainerMaster.Add(new ContainerMaster
                                {
                                    FileId = fileMaster.Id,
                                    ContainerNo = file.Container,
                                    SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                                });
                            }
                        }
                        
                        _context.SaveChanges();

                        var fileLog = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id && x.ContainerNo == file.Container);
                       
                        _context.FileActivityLog.Add(new FileActivityLog
                        {
                            ContainerId = fileLog.Id,
                            ActivityId = carrierRequest.Id,
                            StatusId = null,
                            Comment = null,
                            UserId = userid,
                            StartDate = null,
                            EndDate = null,
                        });
                        _context.SaveChanges();

                        if (file.HBLNumbers.Count() != 0)
                        {
                            foreach (var number in file.HBLNumbers)
                            {
                                var duplicateHBL = _context.HBLMaster.Include(x => x.ContainerMaster).ThenInclude(x => x.FileMaster).Where(x => x.HBLNumber == number && x.ContainerId != null).ToList();
                                if (duplicateHBL.Count() != 0)
                                {
                                    var table = "<div class='box'><div class='box-header with-border'><h3 class='box-title' style='font-weight: bold; color:black; background-color: #ffc107; font-size: 14px;'>HBL Number already added to different File</h3></div><div class='box-body'><table class='table table-bordered'><thead><tr><th style='font-weight: bold; color:black; background-color: #ffc107; padding:0.2rem;'>File Number</th><th style='font-weight: bold; color:black; background-color: #ffc107; padding:0.2rem;'>HBL Number</th></tr></thead><tbody>";

                                    for (int i = 0; i < duplicateHBL.Count; i++)
                                    {
                                        table += "<tr style='color:black; padding:0.2rem;'><td style='color:black; padding:0.2rem;'>" + duplicateHBL[i].ContainerMaster.FileMaster.FileNumber + "</td><td style='color:black; padding:0.2rem;'>" + duplicateHBL[i].HBLNumber + "</td></tr>";
                                    }

                                    table += "</tbody></table></div></div>";
                                    Msg = table; // Return the entire table HTML

                                    //Msg = "Duplicate Booking and HBL numbers:<br>" + table;
                                    //return Content(Msg, "text/html");
                                    return Json(Msg);
                                }
                                else
                                {
                                    var hbl = _context.HBLMaster.FirstOrDefault(x => x.Id == number);
                                    hbl.ContainerId = fileLog.Id;
                                    _context.HBLMaster.Update(hbl);
                                }
                            }
                            _context.SaveChanges();
                        }
                        else
                        {
                            return Json("Please select hbl numbers");
                        }
                    }
                    else
                    {
                        return Json("Duplicate");
                    }

                    if (file.COB == true)
                    {
                        if (file.HBLNumbers.Count() != 0)
                        {
                            foreach (var number in file.HBLNumbers)
                            {
                                _context.COBActivity.Add(new COBActivity
                                {
                                    //ContainerId = fileMaster.Id,
                                    HBLId = number,
                                    UserId = userid,
                                    StartDate = Convert.ToDateTime(file.StartDateTime).ToUniversalTime(),
                                    EndDate = DateTime.UtcNow,
                                });
                            }
                            _context.SaveChanges();
                        }
                        else
                        {
                            return Json("Please select hbl numbers");
                        }
                    }

                    _context.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    if (fileMaster == null)
                    {
                        fileMaster = new FileMaster
                        {
                            POD = file.CountryId,
                            FileNumber = file.FileNumber.ToUpper().Trim(),
                            ETD = ETD,
                            ShippingAgent = file.ShippingAgent,
                            ShippingLine = file.ShippingLine,
                            FileContact = file.FileContact,
                            TotalBL = file.TotalHBL,
                            ETA = ETA,
                            ETAPOD = ETAPOD,
                            ATD = ATD,
                            EnterDate = DateTime.UtcNow,
                            IsActive = true,
                            IsDelete = false
                        };
                        
                        _context.FileMaster.Add(fileMaster);

                        var fileContainer = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id);
                        var containermaster = _context.ContainerMaster.Where(x => x.FileId == fileMaster.Id && x.ContainerNo == file.Container).FirstOrDefault();
                        
                        if (containermaster != null)
                        {
                            containermaster.FileId = file.Id;
                            containermaster.ContainerNo = file.Container;
                            _context.ContainerMaster.Update(containermaster);
                        }
                        else
                        {
                            if (fileContainer != null)
                            {
                                fileContainer.FileId = fileMaster.Id;
                                fileContainer.ContainerNo = file.Container == null ? null : file.Container;
                                _context.ContainerMaster.Update(fileContainer);
                            }
                            else
                            {
                                _context.ContainerMaster.Add(new ContainerMaster
                                {
                                    FileId = fileMaster.Id,
                                    ContainerNo = file.Container == null ? null : file.Container,
                                    SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime(),
                                });
                            }
                        }

                        _context.SaveChanges();

                        var fileLog = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id && x.ContainerNo == file.Container);
                        
                        _context.FileActivityLog.Add(new FileActivityLog
                        {
                            ContainerId = fileLog.Id,
                            ActivityId = carrierRequest.Id,
                            StatusId = null,
                            Comment = null,
                            UserId = userid,
                            StartDate = null,
                            EndDate = null,
                        });
                        _context.SaveChanges();

                        if (file.HBLNumbers.Count() != 0)
                        {
                            foreach (var number in file.HBLNumbers)
                            {
                                var duplicateHBL = _context.HBLMaster.Include(x => x.ContainerMaster).ThenInclude(x => x.FileMaster).Where(x => x.HBLNumber == number && x.ContainerId != null).ToList();
                                if (duplicateHBL.Count() != 0)
                                {
                                    var table = "<div class='box'><div class='box-header with-border'><h3 class='box-title' style='font-weight: bold; color:black; background-color: #ffc107; font-size: 14px;'>HBL Number already added to different File</h3></div><div class='box-body'><table class='table table-bordered'><thead><tr><th style='font-weight: bold; color:black; background-color: #ffc107; padding:0.2rem;'>File Number</th><th style='font-weight: bold; color:black; background-color: #ffc107; padding:0.2rem;'>HBL Number</th></tr></thead><tbody>";

                                    for (int i = 0; i < duplicateHBL.Count; i++)
                                    {
                                        table += "<tr style='color:black; padding:0.2rem;'><td style='color:black; padding:0.2rem;'>" + duplicateHBL[i].ContainerMaster.FileMaster.FileNumber + "</td><td style='color:black; padding:0.2rem;'>" + duplicateHBL[i].HBLNumber + "</td></tr>";

                                    }

                                    table += "</tbody></table></div></div>";
                                    Msg = table; // Return the entire table HTML

                                    //Msg = "Duplicate Booking and HBL numbers:<br>" + table;
                                    //return Content(Msg, "text/html");
                                    return Json(Msg);
                                }
                                else
                                {
                                    var hbl = _context.HBLMaster.FirstOrDefault(x => x.Id == number);
                                    hbl.ContainerId = fileLog.Id;
                                    _context.HBLMaster.Update(hbl);
                                }
                            }
                        }
                        else
                        {
                            return Json("Please select hbl numbers");
                        }
                    }
                    else
                    {
                        return Json("Duplicate");
                    }

                    if (file.COB == true)
                    {
                        if (file.HBLNumbers.Count() != 0)
                        {
                            foreach (var number in file.HBLNumbers)
                            {
                                _context.COBActivity.Add(new COBActivity
                                {
                                    HBLId = number,
                                    UserId = userid,
                                    StartDate = Convert.ToDateTime(file.StartDateTime).ToUniversalTime(),
                                    EndDate = DateTime.UtcNow,
                                });
                            }
                            _context.SaveChanges();
                        }
                        else
                        {
                            return Json("Please select hbl numbers");
                        }
                    }

                    _context.SaveChanges();
                    return Json("Success");
                }
            }
            else
            {
                return Json("Error while processing the request");
            }
        }


        [HttpGet]
        public IActionResult CreateHBL()
        {
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Container"] = _context.ContainerMaster.OrderBy(x => x.FileMaster.EnterDate).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult AddNewHBLActivity(HBLUserViewModel hbl)
        {
            string Msg = "";
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var carrierRequest = _context.ActivityMaster.FirstOrDefault(x => x.NameOfActivity == "Carrier request" && x.IsActive == true && x.IsDelete == false);
            List<string> hblNumbers = hbl.HBLNumbers;
            List<string> bookingNumbers = hbl.BookingNumbers;
            List<HBLMaster> hblMaster = new List<HBLMaster>();
            HBLMaster hblMasters = new HBLMaster();

            if (ModelState.IsValid)
            {
                if (hblNumbers.Count != bookingNumbers.Count)
                {
                    Msg = "The count of HBL numbers and Booking numbers should be the same.";
                }
                else
                {
                    foreach (var hblNumber in hblNumbers)
                    {
                        // Check if the HBL number already exists in the database
                        hblMasters = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber.ToUpper() == hblNumber.ToUpper().Trim());
                        if (hblMasters != null)
                        {
                            hblMaster.Add(hblMasters);
                        }
                    }

                    if (hblMaster.Count == 0)
                    {
                        for (int i = 0; i < hblNumbers.Count; i++)
                        {
                            var hblNumber = hblNumbers[i];
                            var bookingNumber = bookingNumbers[i];
                            //var customerName = customerNames[i];
                            // Check if the HBL number already exists in the database
                            hblMasters = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber.ToUpper() == hblNumber.ToUpper().Trim());
                            if (hblMasters == null)
                            {
                                // Perform actions with each HBL number, e.g., save to a database
                                hblMasters = new HBLMaster
                                {
                                    HBLNumber = hblNumber,
                                    Booking = bookingNumber,
                                    EnterDate = DateTime.UtcNow,
                                    CountryId = hbl.CountryId,
                                    IsActive = true,
                                    IsDelete = false
                                };
                                _context.HBLMaster.Add(hblMasters);
                                _context.SaveChanges();
                            }

                            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
                            if (role == "User")
                            {
                                var hbllist = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber.ToUpper() == hblNumber.ToUpper().Trim());
                                HBLActivityLog hBLActivityLog = _context.HBLActivityLog.Include(x => x.Hbl).FirstOrDefault(x => x.Hbl.HBLNumber == hblNumber.ToUpper().Trim());

                                hBLActivityLog = new HBLActivityLog
                                {
                                    HBLId = hbllist.Id,
                                    ActivityId = hbl.HBLActivities[0].ActivityId,
                                    StatusId = hbl.HBLActivities[0].StatusId,
                                    UserId = userid,
                                    Comment = hbl.HBLActivities[0].Comment,
                                    StartDate = Convert.ToDateTime(hbl.StartDateTime).ToUniversalTime(),
                                    EmailReceivedDate = hbl.EmailReceivedDate != null ? Convert.ToDateTime(hbl.EmailReceivedDate).ToUniversalTime() : (DateTime?)null,
                                    EndDate = DateTime.UtcNow
                                };
                                _context.HBLActivityLog.Add(hBLActivityLog);
                                _context.SaveChanges();

                                if (hbl.DAP == true)
                                {
                                    var daplist = _context.DAPActivity.Include(x => x.Status).Include(x => x.ApplicationUser).Include(x => x.HBLMaster).ThenInclude(x => x.ContainerMaster).ThenInclude(x => x.FileMaster).ThenInclude(x => x.CountryMaster).FirstOrDefault(x => x.HBLMaster.HBLNumber == hblNumber.ToUpper().Trim());
                                    daplist = new DAPActivity
                                    {
                                        HBLId = hbllist.Id,
                                        UserId = userid,
                                    };
                                    _context.DAPActivity.Add(daplist);
                                    _context.SaveChanges();
                                }
                                Msg = "HBL Inserted Successfully..!!";
                            }
                            else
                            {

                                var hbllist = _context.HBLMaster.FirstOrDefault(x => x.HBLNumber.ToUpper() == hblNumber.ToUpper().Trim());
                                HBLActivityLog hBLActivityLog = _context.HBLActivityLog.Include(x => x.Hbl).FirstOrDefault(x => x.Hbl.HBLNumber == hblNumber.ToUpper().Trim());
                                hBLActivityLog = new HBLActivityLog
                                {
                                    HBLId = hbllist.Id,
                                    ActivityId = hbl.HBLActivities[0].ActivityId,
                                    StatusId = hbl.HBLActivities[0].StatusId,
                                    UserId = userid,
                                    Comment = hbl.HBLActivities[0].Comment,
                                    StartDate = Convert.ToDateTime(hbl.StartDateTime).ToUniversalTime(),
                                    EmailReceivedDate = hbl.EmailReceivedDate != null ? Convert.ToDateTime(hbl.EmailReceivedDate).ToUniversalTime() : (DateTime?)null,
                                    EndDate = DateTime.UtcNow
                                };
                                _context.HBLActivityLog.Add(hBLActivityLog);
                                _context.SaveChanges();

                                if (hbl.DAP == true)
                                {
                                    var daplist = _context.DAPActivity.Include(x => x.Status).Include(x => x.ApplicationUser).Include(x => x.HBLMaster).ThenInclude(x => x.ContainerMaster).ThenInclude(x => x.FileMaster).ThenInclude(x => x.CountryMaster).FirstOrDefault(x => x.HBLMaster.HBLNumber == hblNumber.ToUpper().Trim());
                                    daplist = new DAPActivity
                                    {
                                        HBLId = hbllist.Id,
                                        UserId = userid,
                                    };
                                    _context.DAPActivity.Add(daplist);
                                    _context.SaveChanges();
                                }
                            }
                            Msg = "HBL Inserted Successfully..!!";
                        }
                    }
                    else
                    {
                        var table = "<div class='box'><div class='box-header with-border'><h3 class='box-title' style='font-weight: bold; color:black; background-color: #ffc107; font-size: 14px;'>Duplicate Booking and HBL Numbers</h3></div><div class='box-body'><table class='table table-bordered'><thead><tr><th style='font-weight: bold; color:black; background-color: #ffc107; padding:0.2rem;'>Bookings</th><th style='font-weight: bold; color:black; background-color: #ffc107; padding:0.2rem;'>HBL</th></tr></thead><tbody>";

                        for (int i = 0; i < hblMaster.Count; i++)
                        {
                            table += "<tr style='color:black; padding:0.2rem;'><td style='color:black; padding:0.2rem;'>" + hblMaster[i].Booking + "</td><td style='color:black; padding:0.2rem;'>" + hblMaster[i].HBLNumber + "</td></tr>";
                        }

                        table += "</tbody></table></div></div>";
                        Msg = table; // Return the entire table HTML

                        //Msg = "Duplicate Booking and HBL numbers:<br>" + table;
                        //return Content(Msg, "text/html");
                        return Json(Msg);
                    }
                }
            }
            else
            {
                Msg = "Error while processing the request";
            }

            return Json(Msg);
        }


        [HttpGet]
        public IActionResult InsertFile()
        {
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            ViewData["Container"] = _context.ContainerMaster.OrderBy(x => x.FileMaster.EnterDate).ToList();
            ViewData["HBL"] = _context.HBLMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["HBList"] = _context.HBLMaster.Where(x => x.ContainerId == null && x.IsActive == true && x.IsDelete == false).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult InsertNewFile(FileInsertModel file)
        {
            if (ModelState.IsValid)
            {
                FileMaster fileMaster = _context.FileMaster.FirstOrDefault(x => x.FileNumber.Contains(file.FileNumber.ToUpper().Trim()));

                if (fileMaster == null)
                {
                    fileMaster = new FileMaster
                    {
                        POD = file.CountryId,
                        FileNumber = file.FileNumber,
                        ETD = Convert.ToDateTime(file.ETD).ToUniversalTime(),
                        ShippingAgent = file.ShippingAgent,
                        ShippingLine = file.ShippingLine,
                        FileContact = file.FileContact,
                        TotalBL = file.TotalHBL,
                        ETA = Convert.ToDateTime(file.ETA).ToUniversalTime(),
                        ETAPOD = Convert.ToDateTime(file.ETAPOD).ToUniversalTime(),
                        ATD = Convert.ToDateTime(file.ATD).ToUniversalTime(),
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.FileMaster.Add(fileMaster);
                }
                else
                {
                    fileMaster.POD = file.CountryId;
                    fileMaster.FileNumber = file.FileNumber;
                    fileMaster.ETD = Convert.ToDateTime(file.ETD).ToUniversalTime();
                    fileMaster.ShippingAgent = file.ShippingAgent;
                    fileMaster.ShippingLine = file.ShippingLine;
                    fileMaster.FileContact = file.FileContact;
                    fileMaster.TotalBL = file.TotalHBL;
                    fileMaster.ETA = Convert.ToDateTime(file.ETA).ToUniversalTime();
                    fileMaster.ETAPOD = Convert.ToDateTime(file.ETAPOD).ToUniversalTime();
                    fileMaster.ATD = Convert.ToDateTime(file.ATD).ToUniversalTime();
                    fileMaster.EnterDate = DateTime.UtcNow;
                    fileMaster.IsActive = true;
                    fileMaster.IsDelete = false;
                    _context.FileMaster.Update(fileMaster);
                }

                var container = _context.ContainerMaster.FirstOrDefault(x => x.FileId == fileMaster.Id && x.ContainerNo == file.Container);

                if (container == null)
                {
                    _context.ContainerMaster.Add(new ContainerMaster
                    {
                        FileId = fileMaster.Id,
                        ContainerNo = file.Container,
                        SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime()
                    });
                }
                else
                {
                    container.FileId = fileMaster.Id;
                    container.ContainerNo = file.Container;
                    container.SICutOff = Convert.ToDateTime(file.SICutOff).ToUniversalTime();
                    _context.ContainerMaster.Update(container);
                }

                _context.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        public ActionResult GetContainers(string fileNumber)
        {
            var containers = new List<ContainerMaster>();
            var fileId = _context.FileMaster.Where(x => x.FileNumber == fileNumber).Select(x => x.Id).FirstOrDefault();
            var containerList = _context.ContainerMaster.Where(x => x.FileId == fileId).ToList();
            var response = new
            {
                containers = containerList
            };

            return Json(containerList);
        }


        public IActionResult FileQuery(string activityId)
        {
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.Id == activityId && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetFilesQuery(string country, string fileNumber, string activity, string search, string type, string status)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            var filesData = _context.FileActivityLog
                .Include(x => x.ContainerMaster)
                    .ThenInclude(x => x.FileMaster)
                        .ThenInclude(x => x.CountryMaster)
                .Include(x => x.Activity)
                .Include(x => x.ApplicationUser)
                .Include(x => x.Status)
                .Select(x => new FileDashModel
                {
                    Id = x.Id,
                    POD = x.ContainerMaster.FileMaster.CountryMaster.CountryName,
                    EnterDate = x.ContainerMaster.FileMaster.EnterDate,
                    FileNumber = x.ContainerMaster.FileMaster.FileNumber,
                    ContainerNo = x.ContainerMaster.ContainerNo,
                    ETD = x.ContainerMaster.FileMaster.ETD,
                    SICutOff = x.ContainerMaster.SICutOff,
                    ActivityId = x.Activity.NameOfActivity,
                    ActivityType = x.Activity.ActivityType,
                    UserId = role != "User" ? x.ApplicationUser.UserName : x.ApplicationUser.UserName,
                    StatusId = x.Status.Status,
                    Comment = x.Comment == null ? "" : x.Comment,
                    CurrentUser = userid,
                    Role = role
                }).AsQueryable();

            IQueryable<FileDashModel> data = filesData.AsQueryable();
            DateTime date = DateTime.UtcNow;

            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
            }
            if (date != null)
            {
                data = data.Where(x => x.SICutOff.Value.Date >= date.Date || x.SICutOff.Value.Date == null);
            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
            {
                data = data.Where(x => x.StatusId == status);
            }
            else
            {
                data = data.Where(x => x.StatusId != "Completed");
            }

            if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
            {
                data = data.Where(x => x.POD == country);
            }

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                data = data.Where(x => x.ActivityId == activity);
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                data = data.OrderBy(sortColumn + " " + sortColumnDirection);
            }
            else
            {
                sortColumn = "enterDate";
                sortColumnDirection = "desc";
                data = data.OrderBy(sortColumn + " " + sortColumnDirection);
            }

            var files = data
                .Where(x => x.StatusId != "Completed" && x.StatusId != "WIP" && x.StatusId != null)
                .OrderBy(sortColumn + " " + sortColumnDirection)
                .Skip(skip)
                .Take(pageSize)
                .ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = filesData.Count(),
                recordsFiltered = files.Count(),
                data = files
            });
        }

        [HttpGet]
        public IActionResult GetfileData(string fileNumber)
        {
            var hbl = _context.HBLMaster.Where(x => x.ContainerMaster.FileMaster.FileNumber == fileNumber).ToList();
            var file = _context.FileMaster.Where(x => x.FileNumber == fileNumber).Select(x => new { x.Id }).FirstOrDefault();
            var sm = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            var fm = _context.FileActivityLog.Include(x => x.ContainerMaster.FileMaster).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.ContainerId == file.Id).ToList();
            IQueryable<FileActivityLog> fileActivityLog = fm.AsQueryable();
            return Json(new { fm, hbl, sm });
        }

        public IActionResult HBLQuery(string activityId, string fileNumber)
        {
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.Id == activityId && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetHBLQuery(string country, string hblNumber, string activity, string search, string type)
        {
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

            // Create a base query
            var data = _context.HBLActivityLog
                .Include(x => x.Hbl)
                .Include(x => x.Hbl.ContainerMaster.FileMaster.CountryMaster)
                .Include(x => x.Activity)
                .Include(x => x.ApplicationUser)
                .Include(x => x.Status)
                .Select(x => new HBLDashViewModel
                {
                    Id = x.Id,
                    POD = x.Hbl.ContainerMaster.FileMaster.CountryMaster.CountryName,
                    FileNumber = x.Hbl.ContainerMaster.FileMaster.FileNumber,
                    BookingNo = x.Hbl.Booking,
                    HBLNumber = x.Hbl.HBLNumber,
                    Activity = x.Activity.NameOfActivity,
                    ActivityType = x.Activity.ActivityType,
                    User = x.ApplicationUser.UserName,
                    Status = x.Status.Status,
                    StatusId = x.StatusId,
                    Comment = x.Comment,
                    CurrentUser = userId,
                    Role = role
                }).AsQueryable();

            IQueryable<HBLDashViewModel> baseQuery = data.AsQueryable();

            // Apply filters
            if (!string.IsNullOrEmpty(hblNumber))
            {
                baseQuery = baseQuery.Where(x => x.FileNumber.Contains(hblNumber.Trim()));
            }
            if (!string.IsNullOrEmpty(country) && country != "none" && country != "--Select--")
            {
                baseQuery = baseQuery.Where(x => x.POD == country);
            }
            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                baseQuery = baseQuery.Where(x => x.Activity == activity);
            }

            // Apply sorting
            if (string.IsNullOrEmpty(sortColumn))
            {
                sortColumn = "hblNumber";
            }
            baseQuery = baseQuery.OrderBy(sortColumn + " " + sortColumnDirection);

            // Count total records without pagination
            int totalRecords = baseQuery.Count();

            // Apply pagination and get the data
            var files = baseQuery
                .Where(x => x.Status != "Completed" && x.Status != "WIP" /*&& (role != "User" || x.User == userId)*/)
                .Skip(skip)
                .Take(pageSize)
                .ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = data.Count(),
                recordsFiltered = files.Count(),
                data = files
            });
        }

        [HttpGet]
        public IActionResult GetHBLActivityQuery(string Id)
        {
            var sm = _context.StatusMaster.ToList();
            var HBL = _context.HBLActivityLog.Where(fileActivity => fileActivity.HBLId == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {
                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().Where(x => x.Status == "Query").AsQueryable();

            return Json(new { HBL, sm, Id });
        }

        public IActionResult HBLActivityChangeStatus(string id, string status, string comment, string startDate)
        {
            var hblActivity = _context.HBLActivityLog.Where(x => x.Id == id).FirstOrDefault();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var hblActivityLog = _context.HBLActivityLog.Where(x => x.Id == id && x.ActivityId == hblActivity.ActivityId).FirstOrDefault();

            _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
            {
                HblLogId = hblActivity.Id,
                ActivityId = hblActivity.ActivityId,
                StatusId = hblActivity.StatusId,
                Comment = hblActivity.Comment,
                UserId = hblActivity.UserId,
                StartDate = hblActivity.StartDate,
                EndDate = hblActivity.EndDate,
            });
            _context.SaveChanges();

            if (hblActivity != null)
            {
                hblActivityLog.StatusId = status;
                hblActivityLog.Comment = comment;
                hblActivityLog.UserId = userid;
                hblActivityLog.StartDate = Convert.ToDateTime(startDate).ToUniversalTime();
                hblActivityLog.EndDate = DateTime.UtcNow;
                _context.HBLActivityLog.Update(hblActivityLog);
                _context.SaveChanges();
            }
            else
            {
                return Json("Error while processing the request.");
            }

            return Json("success");
        }

        public IActionResult FileActivityChangeStatus(string id, string status, string comment, string startDate)
        {
            var fileActivity = _context.FileActivityLog.Where(x => x.Id == id).FirstOrDefault();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivityLog = _context.FileActivityLog.Where(x => x.Id == id && x.ActivityId == fileActivity.ActivityId).FirstOrDefault();

            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
            {
                FileLogId = fileActivity.Id,
                ActivityId = fileActivity.ActivityId,
                StatusId = fileActivity.StatusId,
                Comment = fileActivity.Comment,
                UserId = fileActivity.UserId,
                StartDate = fileActivity.StartDate,
                EndDate = fileActivity.EndDate,
            });
            _context.SaveChanges();

            if (fileActivity != null)
            {
                fileActivityLog.StatusId = status;
                fileActivityLog.Comment = comment;
                fileActivityLog.UserId = userid;
                fileActivityLog.StartDate = Convert.ToDateTime(startDate).ToUniversalTime();
                fileActivityLog.EndDate = DateTime.UtcNow;
                _context.FileActivityLog.Update(fileActivityLog);
                _context.SaveChanges();
            }
            else
            {
                return Json("Error while processing the request.");
            }

            return Json("success");
        }
        public IActionResult UserThread()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var activityFile = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true).OrderBy(x => x.FileSequence).ToList();
            var activityHbl = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && (x.NameOfActivity == "HBL Processing" || x.NameOfActivity == "BL Request")).ToList();
            var activity = activityFile.Concat(activityHbl).ToList();
            ViewData["Country"] = _context.CountryMaster.ToList();
            foreach (var item in activity)
            {
                if (item.ActivityType == "File")
                {
                    item.NameOfActivity += " (F)";
                }
                else
                {
                    item.NameOfActivity += " (H)";
                }
            }

            ViewData["Activity"] = activity;
            return View();
        }

        [HttpGet]
        public IActionResult GetHblData(string id)
        {
            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var sm = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            var fm = _context.FileActivityLog.Include(x => x.ContainerMaster).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.ContainerId == id).Select(x => new FileDashModel
            {
                ContainerId = x.ContainerId,
                ActivityId = x.Activity.NameOfActivity,
                StatusId = x.Status.Status,
                UserId = x.ApplicationUser.CitrixId,
                StartDate = x.StartDate,
                EndDate = x.EndDate,
                LBL = _context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && y.HBLNumber.StartsWith("SIN")).Count(),
                TBL = _context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count(),
                TotalHBL = (_context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && y.HBLNumber.StartsWith("SIN")).Count()) + (_context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count())
            }).ToList();

            fm = fm.Select(x => new FileDashModel
            {
                ContainerId = x.ContainerId,
                ActivityId = x.ActivityId,
                StatusId = x.StatusId,
                UserId = x.UserId,
                StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                LBL = x.LBL,
                TBL = x.TBL,
                TotalHBL = x.TotalHBL
            }).ToList();

            var hblIdList = _context.HBLMaster.Where(x => x.ContainerId == id).Select(x => x.Id).ToList();
            var hbl = new List<HBLDashViewModel>();

            foreach (var hblId in hblIdList)
            {
                var hblActivityLogRecords = _context.HBLActivityLog
                    .Include(x => x.Hbl)
                    .Include(x => x.Hbl.ContainerMaster)
                    .Include(x => x.Activity)
                    .Include(x => x.Status)
                    .Include(x => x.ApplicationUser)
                    .Where(x => x.HBLId == hblId)
                    .Select(x => new HBLDashViewModel
                    {
                        Id = x.HBLId,
                        ContainerNo = x.Hbl.ContainerMaster.ContainerNo,
                        FileNumber = x.Hbl.ContainerMaster.FileMaster.FileNumber,
                        HBLNumber = x.Hbl.HBLNumber,
                        CustomerName = x.Hbl.CustomerName == null ? "" : x.Hbl.CustomerName,
                        BookingNo = x.Hbl.Booking,
                        Activity = x.Activity.NameOfActivity,
                        EmailReceivedDate = x.EmailReceivedDate.HasValue ? x.EmailReceivedDate : (DateTime?)null,
                        Status = x.Status.Status,
                        User = x.ApplicationUser.UserName == null ? "" : x.ApplicationUser.CitrixId,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate,
                    }).ToList();

                hblActivityLogRecords = hblActivityLogRecords.Select(x => new HBLDashViewModel
                {
                    Id = x.Id,
                    ContainerNo = x.ContainerNo,
                    FileNumber = x.FileNumber,
                    HBLNumber = x.HBLNumber,
                    CustomerName = x.CustomerName,
                    BookingNo = x.BookingNo,
                    Activity = x.Activity,
                    EmailReceivedDate = x.EmailReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EmailReceivedDate.Value, istTimeZone) : (DateTime?)null,
                    Status = x.Status,
                    User = x.User,
                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                }).ToList();

                hbl.AddRange(hblActivityLogRecords);
            }

            fm = fm.OrderByDescending(x => x.ActivityId).ToList();
            hbl = hbl.OrderByDescending(x => x.Activity).ToList();
            return Json(new { fm, hbl, sm });
        }

        public async Task<IActionResult> UserDashboard(string activityId)
        {
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["ActivityMaster"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["ActivityId"] = _context.ActivityMaster.Where(x => x.Id == activityId && x.IsActive == true && x.IsDelete == false).ToList();
            return View();
        }

        [Authorize(Roles = "User")]
        [HttpPost]
        public IActionResult GetUserDashboard(/*string activity,*/ string Country, string fileNumber, string search, string status)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            DateTime date = DateTime.UtcNow;
            DateTime threeMonth = DateTime.UtcNow.AddMonths(-3);

            List<FileDashModel> fileDashModel = new List<FileDashModel>();

            var fileData = _context.ContainerMaster.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null)
                .Include(x => x.FileMaster)
                .Include(x => x.FileActivityLogs)
                    .ThenInclude(x => x.ApplicationUser)
                .Select(x => new FileDashModel
                {
                    Id = x.FileMaster.Id,
                    FileId = x.FileMaster.Id,
                    FileLogId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).Select(y => y.Id).FirstOrDefault(),
                    EnterDate = x.FileMaster.EnterDate,
                    FileNumber = x.FileMaster.FileNumber.Substring(0, x.FileMaster.FileNumber.Length - 6),
                    POD = x.FileMaster.CountryMaster.CountryName,
                    ETD = x.FileMaster.ETD,
                    ETAPOD = x.FileMaster.ETAPOD,
                    ETA = x.FileMaster.ETA,
                    ATD = x.FileMaster.ATD,
                    SICutOff = x.SICutOff,
                    ShippingLine = x.FileMaster.ShippingLine,
                    FileContact = x.FileMaster.FileContact,
                    UserId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().ApplicationUser.UserName ?? "",
                    StatusId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Status.Status ?? "UnAllocated",
                    ActivityId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.NameOfActivity ?? "",
                    ActivityType = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.ActivityType ?? "",
                    ContainerNo = x.ContainerNo,
                    ContainerId = x.Id,
                    Comment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Comment,
                    Roe = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Roe != null).FirstOrDefault().Roe,
                    CurrentUser = userName,
                    EndDate = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().EndDate,
                    CarrierBookingsId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Carrier Bookings").FirstOrDefault().Status.Status ?? "UnAllocated",
                    CarrierBookingsCompleted = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Carrier Bookings").FirstOrDefault().EndDate,
                    PresailingId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Sailing Schedule/Pre-sailing").FirstOrDefault().Status.Status ?? "UnAllocated",
                    PresailingCompleted = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Sailing Schedule/Pre-sailing").FirstOrDefault().EndDate,
                    VesselChangeId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Vessel Change/Delay Notices").FirstOrDefault().Status.Status ?? "UnAllocated",
                    VesselChangeCompleted = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Vessel Change/Delay Notices").FirstOrDefault().EndDate,
                    SIRequesttoShipperId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "SI Request to Shipper/Follow ups").FirstOrDefault().Status.Status ?? "UnAllocated",
                    SIRequesttoShipperCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "SI Request to Shipper/Follow ups").FirstOrDefault().EndDate,
                    MBLReviewId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "MBL Review/Amendment").FirstOrDefault().Status.Status ?? "UnAllocated",
                    MBLReviewCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "MBL Review/Amendment").FirstOrDefault().EndDate,
                    BondProcessingId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Bond Processing (Canada)").FirstOrDefault().Status.Status ?? "UnAllocated",
                    BondProcessingCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Bond Processing (Canada)").FirstOrDefault().EndDate,
                    SIToCarrier = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "SI To Carrier").FirstOrDefault().Status.Status ?? "UnAllocated",
                    SIToCarrierCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "SI To Carrier").FirstOrDefault().EndDate,
                    EDIId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "EDI").FirstOrDefault().Status.Status ?? "UnAllocated",
                    EDICompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "EDI").FirstOrDefault().EndDate,
                    PreAlerttoPODId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Pre-Alert to POD").FirstOrDefault().Status.Status ?? "UnAllocated",
                    PreAlerttoPODCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Pre-Alert to POD").FirstOrDefault().EndDate,
                    ShippingConfirmationId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Shipping Confirmation").FirstOrDefault().Status.Status ?? "UnAllocated",
                    ShippingConfirmationCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "Shipping Confirmation").FirstOrDefault().EndDate,
                    DAPId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "DAP").FirstOrDefault().Status.Status ?? "UnAllocated",
                    DAPCompleted = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "DAP").FirstOrDefault().EndDate,
                    LBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("SIN")).Count(),
                    TBL = x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("SIN")).Count(),
                    TotalHBL = x.HBLMasters.Where(y => y.ContainerId == x.Id).Count() != 0 ? (x.HBLMasters.Where(y => y.ContainerId == x.Id && y.HBLNumber.StartsWith("SIN")).Count()) + (x.HBLMasters.Where(y => y.ContainerId == x.Id && !y.HBLNumber.StartsWith("SIN")).Count()) : x.FileMaster.TotalBL
                }).AsQueryable();

            IQueryable<FileDashModel> SortedData = fileData.AsQueryable();

            if (date != null)
            {
                SortedData = SortedData.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null);
            }
            if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" ||
                search == "Received" || search == "UnAllocated" || search == "etd10" || search == "etd12" || search == "etd18" || search == "si")
            {
                if (search == "etd10")
                {
                    SortedData = SortedData.Where(x => x.ETD != null && Convert.ToDateTime(x.ETD).AddDays(-10) <= DateTime.Now && (x.StatusId != "Completed"));
                }
                else if (search == "etd12")
                {
                    SortedData = SortedData.Where(x => x.ETD != null && Convert.ToDateTime(x.ETD).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.ETD).AddDays(-12) <= DateTime.Now && x.StatusId != "Completed");
                }
                else if (search == "etd18")
                {
                    SortedData = SortedData.Where(x => x.ETD != null && Convert.ToDateTime(x.ETD).AddDays(-12) > DateTime.Now && x.StatusId != "Completed");
                }
                else if (search == "Received")
                {
                    SortedData = SortedData;
                }
                else if (search == "UnAllocated")
                {
                    SortedData = SortedData.Where(x => x.StatusId == "UnAllocated");
                }
                else if (search == "si")
                {
                    SortedData = SortedData.Where(x => x.StatusId != "Completed" && x.SICutOff != null && x.SICutOff.Value.Date == DateTime.Today.Date && x.UserId == userName);
                }
                else
                {
                    SortedData = SortedData.Where(x => x.StatusId == search && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName);
                }
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                sortColumn = "enterDate";
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }

            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);

            SortedData = SortedData.ToList().Select(x => new FileDashModel
            {
                Id = x.Id,
                FileId = x.FileId,
                FileLogId = x.FileLogId,
                EnterDate = x.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EnterDate.Value, istTimeZone) : (DateTime?)null,
                FileNumber = x.FileNumber,
                POD = x.POD,
                ETD = x.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETD.Value, istTimeZone) : (DateTime?)null,
                ETAPOD = x.ETAPOD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETAPOD.Value, istTimeZone) : (DateTime?)null,
                ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
                ATD = x.ATD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ATD.Value, istTimeZone) : (DateTime?)null,
                SICutOff = x.SICutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.SICutOff.Value, istTimeZone) : (DateTime?)null,
                ShippingLine = x.ShippingLine,
                FileContact = x.FileContact,
                FileActivityLogId = x.FileActivityLogId,
                UserId = x.UserId,
                StatusId = x.StatusId,
                ActivityId = x.ActivityId,
                ActivityType = x.ActivityType,
                ContainerNo = x.ContainerNo,
                ContainerId = x.ContainerId,
                Comment = x.Comment,
                Roe = x.Roe,
                EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
                CarrierBookingsId = x.CarrierBookingsId,
                CarrierBookingsCompleted = x.CarrierBookingsCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.CarrierBookingsCompleted.Value, istTimeZone) : (DateTime?)null,
                PresailingId = x.PresailingId,
                PresailingCompleted = x.PresailingCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.PresailingCompleted.Value, istTimeZone) : (DateTime?)null,
                SIRequesttoShipperId = x.SIRequesttoShipperId,
                SIRequesttoShipperCompleted = x.SIRequesttoShipperCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.SIRequesttoShipperCompleted.Value, istTimeZone) : (DateTime?)null,
                TallySheetComment = x.TallySheetComment,
                MblReviewComment = x.MblReviewComment,
                TblProcessingComment = x.TblProcessingComment,
                CarrierRequest = x.CarrierRequest,
                CarrierRequestCompleted = x.CarrierRequestCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.CarrierRequestCompleted.Value, istTimeZone) : (DateTime?)null,
                MBLReviewId = x.MBLReviewId,
                MBLReviewCompleted = x.MBLReviewCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.MBLReviewCompleted.Value, istTimeZone) : (DateTime?)null,
                BLRequestComment = x.BLRequestComment,
                BLRequest = x.BLRequest,
                BondProcessingId = x.BondProcessingId,
                BondProcessingCompleted = x.BondProcessingCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.BondProcessingCompleted.Value, istTimeZone) : (DateTime?)null,
                ShippingConfirmationId = x.ShippingConfirmationId,
                ShippingConfirmationCompleted = x.ShippingConfirmationCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ShippingConfirmationCompleted.Value, istTimeZone) : (DateTime?)null,
                SIToCarrier = x.SIToCarrier,
                SIToCarrierCompleted = x.SIToCarrierCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.SIToCarrierCompleted.Value, istTimeZone) : (DateTime?)null,
                EDIId = x.EDIId,
                EDICompleted = x.EDICompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EDICompleted.Value, istTimeZone) : (DateTime?)null,
                PreAlerttoPODId = x.PreAlerttoPODId,
                PreAlerttoPODCompleted = x.PreAlerttoPODCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.PreAlerttoPODCompleted.Value, istTimeZone) : (DateTime?)null,
                DAPId = x.DAPId,
                DAPCompleted = x.DAPCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.DAPCompleted.Value, istTimeZone) : (DateTime?)null,
                VesselChangeId = x.VesselChangeId,
                VesselChangeCompleted = x.VesselChangeCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.VesselChangeCompleted.Value, istTimeZone) : (DateTime?)null,
                Permit = x.Permit,
                PermitCompleted = x.PermitCompleted.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.PermitCompleted.Value, istTimeZone) : (DateTime?)null,
                LBL = x.LBL,
                TBL = x.TBL,
                TotalHBL = x.TotalHBL
            }).AsQueryable();

            //SortedData = SortedData.Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize);

            var returnObj = new
            {
                draw = draw,
                recordsTotal = fileData.Count(),
                recordsFiltered = SortedData.Count(),
                data = SortedData.ToList(),
            };

            return Json(returnObj);
        }

        public JsonResult GetDashboardCount(string? activity)
        {
            var userId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            DateTime date = DateTime.UtcNow;
            DateTime threeMonth = DateTime.UtcNow.AddMonths(-3);

            var data = _context.ContainerMaster.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null)
                .Include(x => x.FileMaster)
                .Include(x => x.FileActivityLogs)
                    .ThenInclude(x => x.ApplicationUser)
                .Select(x => new FileDashModel
                {
                    Id = x.FileMaster.Id,
                    FileLogId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).Select(y => y.Id).FirstOrDefault(),
                    EnterDate = x.FileMaster.EnterDate,
                    FileNumber = x.FileMaster.FileNumber.Substring(0, x.FileMaster.FileNumber.Length - 6),
                    POD = x.FileMaster.CountryMaster.CountryName,
                    ETD = x.FileMaster.ETD,
                    ETAPOD = x.FileMaster.ETAPOD,
                    ETA = x.FileMaster.ETA,
                    ATD = x.FileMaster.ATD,
                    SICutOff = x.SICutOff,
                    ShippingLine = x.FileMaster.ShippingLine,
                    FileContact = x.FileMaster.FileContact,
                    UserId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().ApplicationUser.UserName ?? "",
                    StatusId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Status.Status ?? "UnAllocated",
                    ActivityId = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.NameOfActivity ?? "",
                    ActivityType = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Activity.ActivityType ?? "",
                    ContainerNo = x.ContainerNo,
                    ContainerId = x.Id,
                    Comment = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().Comment,
                    Roe = x.FileActivityLogs.Where(y => y.ContainerId == x.Id && y.Roe != null).FirstOrDefault().Roe,
                    CurrentUser = userName,
                    EndDate = x.FileActivityLogs.Where(y => y.ContainerId == x.Id).FirstOrDefault().EndDate,
                }).AsQueryable();
            
            if (date != null)
            {
                data = data.Where(x => x.SICutOff.Value.Date >= threeMonth.Date || x.SICutOff.Value.Date == null);
            }
            DashboardProdcount dp = new DashboardProdcount
            {
                Received = data.ToList().Count,
                Pending = data.Count(x => x.StatusId == "Pending" && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName),
                WIP = data.Count(x => x.StatusId == "WIP" && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName),
                Query = data.Count(x => x.StatusId == "Query" && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName),
                Completed = data.Count(x => x.StatusId == "Completed" && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today.Date && x.UserId == userName),
                UnAllocated = data.Count(x => x.StatusId == "UnAllocated"),
                siCutOff = data.Count(x => x.SICutOff != null && x.SICutOff.Value.Date == DateTime.Today.Date && x.UserId == userName && x.StatusId != "Completed"),
            };

            return Json(dp);
        }

        [HttpGet]
        public IActionResult GetContainer(string? fileNo)
        {
            var fileId = _context.FileMaster.Where(x => x.FileNumber == fileNo).Select(x => x.Id).FirstOrDefault();
            var containerList = _context.ContainerMaster.Where(x => x.FileId == fileId).ToList();
            return Json(new { success = "Success", containerList });
        }

        public IActionResult Adhoc()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return View();
        }

        [HttpGet]
        public IActionResult AdhocFileActivity()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.Source == "Adhoc" && x.IsDelete == false && x.IsActive == true).ToList();
            ViewBag.Status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult AdhocFileActivity(AdhocFileActivityModel adhocfileActivity)
        {
            if (ModelState.IsValid)
            {
                AdhocFile adhocfile = _context.AdhocFile.Where(x => x.AdhocFileNumber == adhocfileActivity.AdhocFileNumber.ToUpper().Trim()).FirstOrDefault();

                if (adhocfile == null)
                {
                    adhocfile = new AdhocFile
                    {
                        Id = adhocfileActivity.Id,
                        CountryId = adhocfileActivity.CountryId,
                        AdhocFileNumber = adhocfileActivity.AdhocFileNumber.ToUpper().Trim(),
                        AdhocContainer = adhocfileActivity.AdhocContainer.ToUpper().Trim(),
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.AdhocFile.Add(adhocfile);
                }

                foreach (AdhocFileActivityLogItem log in adhocfileActivity.AdhocFileActivities)
                {
                    _context.AdhocFileActivityLog.Add(new AdhocFileActivityLog
                    {
                        Id = log.Id,
                        AdhocFileId = adhocfile.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });
                }
                _context.SaveChanges();
                return Json(adhocfileActivity.Id);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        [HttpGet]
        public IActionResult AdhocHBLActivity()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.Source == "Adhoc" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult AdhocHBLActivity(AdhocHBLActivityModel adhocHBLActivity)
        {
            if (ModelState.IsValid)
            {
                AdhocHBL adhochbl = _context.AdhocHBL.Where(x => x.AdhocBooking == adhocHBLActivity.AdhocBooking.ToUpper().Trim() || x.AdhocHBLNumber == adhocHBLActivity.AdhocHBLNumber.ToUpper().Trim()).FirstOrDefault();

                if (adhochbl == null)
                {
                    adhochbl = new AdhocHBL
                    {
                        Id = adhocHBLActivity.Id,
                        AdhocCountryId = adhocHBLActivity.AdhocCountryId,
                        AdhocBooking = adhocHBLActivity.AdhocBooking.ToUpper().Trim(),
                        AdhocHBLNumber = adhocHBLActivity.AdhocHBLNumber.ToUpper().Trim(),
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.AdhocHBL.Add(adhochbl);
                }

                foreach (AdhocHBLActivityLogItem log in adhocHBLActivity.AdhocHBLActivities)
                {
                    _context.AdhocHBLActivityLog.Add(new AdhocHBLActivityLog
                    {
                        Id = log.Id,
                        AdhocHBLId = adhochbl.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });

                }
                _context.SaveChanges();
                return Json(adhocHBLActivity.Id);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        [HttpPost]
        public IActionResult GetAdhocFiles(DataTableAjaxPostModel model, string country, string fileNumber, string container)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 10;
            int skip = model.start.HasValue ? model.start.Value : 0;

            // Get the data for the DataTable
            var data = _context.AdhocFileActivityLog
            .Join(_context.AdhocFile, fileActivity => fileActivity.AdhocFileId, fileMaster => fileMaster.Id, (fileActivity, fileMaster) => new { fileActivity, fileMaster })
            .Join(_context.ActivityMaster, activityJoin => activityJoin.fileActivity.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.fileActivity.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.CountryMaster, countryjoin => countryjoin.statusjoin.activityJoin.fileMaster.CountryId, countryMaster => countryMaster.Id, (countryjoin, countryMaster) => new { countryjoin, countryMaster })
            .Join(_context.Users, userjoin => userjoin.countryjoin.statusjoin.activityJoin.fileActivity.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            AdhocFileDashModel
            {
                Id = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.Id,
                CountryName = userjoin.countryMaster.CountryName,
                FileNumber = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.AdhocFileNumber,
                Container = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.AdhocContainer,
                LastActivityPerformed = userjoin.countryjoin.statusjoin.activityMaster.NameOfActivity,
                LastActivityStatus = userjoin.countryjoin.statusMaster.Status,
                LastProcessedDate = userjoin.countryjoin.statusjoin.activityJoin.fileActivity.EndDate,
                LastFileHandler = User.UserName
            })
            .GroupBy(x => x.FileNumber)
            .Select(group => group.OrderByDescending(x => x.LastProcessedDate).First()).ToList().AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
            {
                data = data.Where(x => x.CountryName.Contains(country));
            }
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber));
            }
            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.Container.Contains(container));
            }

            int filteredrecords = data.Count();

            List<AdhocFileDashModel> files = data.Select(
                x => new AdhocFileDashModel
                {
                    Id = x.Id,
                    CountryName = x.CountryName,
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    LastActivityPerformed = x.LastActivityPerformed,
                    LastActivityStatus = x.LastActivityStatus,
                    LastProcessedDate = x.LastProcessedDate,
                }).OrderBy(sortColumn + " " + sortColumnDirection)
               .Skip(skip)
               .Take(pageSize == -1 ? 10 : pageSize).AsQueryable().ToList();

            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = filteredrecords,
                data = files
            });
        }

        [HttpPost]
        public IActionResult GetAdhocHBLs(DataTableAjaxPostModel model, string country, string booking, string hblNumber)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 10;
            int skip = model.start.HasValue ? model.start.Value : 0;

            // Get the data for the DataTable
            var data = _context.AdhocHBLActivityLog
            .Join(_context.AdhocHBL, hblActivity => hblActivity.AdhocHBLId, hblMaster => hblMaster.Id, (hblActivity, hblMaster) => new { hblActivity, hblMaster })
            .Join(_context.ActivityMaster, activityJoin => activityJoin.hblActivity.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.hblActivity.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.CountryMaster, countryjoin => countryjoin.statusjoin.activityJoin.hblMaster.AdhocCountryId, countryMaster => countryMaster.Id, (countryjoin, countryMaster) => new { countryjoin, countryMaster })
            .Join(_context.Users, userjoin => userjoin.countryjoin.statusjoin.activityJoin.hblActivity.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            AdhocHBLDashModel
            {
                Id = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.Id,
                CountryName = userjoin.countryMaster.CountryName,
                HBLNo = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.AdhocHBLNumber,
                BookingNo = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.AdhocBooking,
                LastActivityPerformed = userjoin.countryjoin.statusjoin.activityMaster.NameOfActivity,
                LastActivityStatus = userjoin.countryjoin.statusMaster.Status,
                LastProcessedDate = userjoin.countryjoin.statusjoin.activityJoin.hblActivity.EndDate,
                LastHBLHandler = User.UserName
            })
            .GroupBy(x => x.HBLNo)
            .Select(group => group.OrderByDescending(x => x.LastProcessedDate).First()).ToList().AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "--Select--")
            {
                data = data.Where(x => x.CountryName.Contains(country));
            }
            if (!string.IsNullOrEmpty(booking))
            {
                data = data.Where(x => x.BookingNo.Contains(booking));
            }
            if (!string.IsNullOrEmpty(hblNumber))
            {
                data = data.Where(x => x.HBLNo.Contains(hblNumber));
            }

            int filteredrecords = data.Count();

            List<AdhocHBLDashModel> files = data.Select(
                x => new AdhocHBLDashModel
                {
                    Id = x.Id,
                    CountryName = x.CountryName,
                    BookingNo = x.BookingNo,
                    HBLNo = x.HBLNo,
                    LastActivityPerformed = x.LastActivityPerformed,
                    LastActivityStatus = x.LastActivityStatus,
                    LastProcessedDate = x.LastProcessedDate,
                }).OrderBy(sortColumn + " " + sortColumnDirection)
               .Skip(skip)
               .Take(pageSize == -1 ? 10 : pageSize).AsQueryable().ToList();

            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = filteredrecords,
                data = files
            });
        }

        [HttpPost]
        public JsonResult AddFileActivities(FileActivityLogViewModel model, string button, string? statusValue, string? endDateValue, string? fileComments, string? roeValue)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);            
            var editData = _context.FileActivityLog.FirstOrDefault(x => x.ContainerId == model.ContainerId && x.ActivityId == model.ActivityId);
            var statusMaster = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            var activityMaster = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            var wip = statusMaster.FirstOrDefault(x => x.Status == "WIP" && x.IsActive == true && x.IsDelete == false);
            var wipId = statusMaster.FirstOrDefault(x => x.Status == "WIP" && x.IsActive == true && x.IsDelete == false)?.Id;
            var query = statusMaster.FirstOrDefault(x => x.Status == "Query" && x.IsActive == true && x.IsDelete == false)?.Id;
            var pending = statusMaster.FirstOrDefault(x => x.Status == "Pending" && x.IsActive == true && x.IsDelete == false)?.Id;
            var completed = statusMaster.FirstOrDefault(x => x.Status == "Completed" && x.IsActive == true && x.IsDelete == false)?.Id;
            var completedWithQuery = statusMaster.FirstOrDefault(x => x.Status == "Completed With Query" && x.IsActive == true && x.IsDelete == false)?.Id;
            var SIToCarrier = activityMaster.FirstOrDefault(x => x.NameOfActivity == "SI To Carrier" && x.IsActive == true && x.IsDelete == false)?.Id;
            var MBLReview = activityMaster.FirstOrDefault(x => x.NameOfActivity == "MBL Review" && x.IsActive == true && x.IsDelete == false)?.Id;
            var TBLProcessing = activityMaster.FirstOrDefault(x => x.NameOfActivity == "TBL Processing" && x.IsActive == true && x.IsDelete == false)?.Id;
            var TallySheet = activityMaster.FirstOrDefault(x => x.NameOfActivity == "Tally Sheet" && x.IsActive == true && x.IsDelete == false)?.Id;
            var statusList = statusMaster.FirstOrDefault(x => (x.Status == statusValue || x.Id == statusValue) && x.IsActive == true && x.IsDelete == false);
            var fileList = _context.FileActivityLog.Include(x => x.ContainerMaster).Include(x => x.ApplicationUser).Include(x => x.Status).Include(x => x.Activity).FirstOrDefault(x => x.ContainerId == model.ContainerId && (x.ActivityId == model.ActivityId || x.Activity.NameOfActivity == model.ActivityId));
            var userList = _context.Users.FirstOrDefault(x => (x.CitrixId == model.UserId || x.Id == model.UserId) && x.IsActive == true && x.IsDelete == false);
            var activityId = activityMaster.FirstOrDefault(x => (x.NameOfActivity == model.ActivityId || x.Id == model.ActivityId) && x.IsActive == true && x.IsDelete == false)?.Id;
            var activityList = activityMaster.FirstOrDefault(x => (x.NameOfActivity == model.ActivityId || x.Id == model.ActivityId) && x.IsActive == true && x.IsDelete == false);
            var statusId = statusMaster.FirstOrDefault(x => (x.Status == model.StatusId || x.Id == model.StatusId) && x.IsActive == true && x.IsDelete == false)?.Id;
            string? userId = (userList != null) ? userList?.Id : null;
            string? selectedStatusId = (statusValue != "UnAllocated") ? statusList?.Id : null;

            if (model.StartDate != null)
            {
                DateTime startDate = DateTime.ParseExact(model.StartDate, "dd MMM yyyy HH:mm", CultureInfo.InvariantCulture);
                model.StartDate = startDate.ToString("MM/dd/yyyy HH:mm");
            }
            if (model.SI != null)
            {
                DateTime si = DateTime.ParseExact(model.SI, "dd MMM yyyy HH:mm", CultureInfo.InvariantCulture);
                model.SI = si.ToString("MM/dd/yyyy HH:mm");
            }
            if (button == "Edit")
            {
                if (ModelState.IsValid)
                {
                    if (model.StatusId != wip.Status || model.UserId == userName)
                    {
                        if (fileList != null)
                        {
                            fileList.ContainerId = model.ContainerId;
                            fileList.ActivityId = activityId;
                            fileList.StatusId = wip.Id;
                            fileList.UserId = userid;
                            fileList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                            fileList.Roe = model.Roe;
                            _context.FileActivityLog.Update(fileList);
                        }
                        else
                        {
                            var containerData = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);

                            if (containerData == null)
                            {
                                _context.ContainerMaster.Add(new ContainerMaster
                                {
                                    ContainerNo = model.ContainerNo,
                                    FileId = model.FileId,
                                    SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                                });
                                _context.SaveChanges();

                                containerData = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);
                            }

                            _context.FileActivityLog.Add(new FileActivityLog
                            {
                                ContainerId = containerData.Id,
                                ActivityId = activityId,
                                StatusId = (model.StatusId != wip.Status) ? wip.Id : statusId,
                                UserId = userid,
                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                EndDate = DateTime.UtcNow,
                                Comment = model.Comment,
                                Roe = model.Roe
                            });
                            _context.SaveChanges();
                        }
                        _context.SaveChanges();
                        return Json("Success");
                    }
                    else
                    {
                        return Json("Activity is processed by another user");
                    }
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else if (button == "Cancel")
            {
                if (ModelState.IsValid)
                {
                    var user = "";
                    if (model.StatusId == "UnAllocated" || statusValue == "UnAllocated")
                    {
                        user = null;
                    }
                    else
                    {
                        user = userid;
                    }
                    if (fileList != null)
                    {
                        fileList.ContainerId = model.ContainerId;
                        fileList.ActivityId = activityId;
                        fileList.StatusId = selectedStatusId;
                        fileList.UserId = user;
                        fileList.Roe = roeValue;
                        _context.FileActivityLog.Update(fileList);
                    }
                    else
                    {
                        var containerData = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);

                        if (containerData == null)
                        {
                            _context.ContainerMaster.Add(new ContainerMaster
                            {
                                ContainerNo = model.ContainerNo,
                                FileId = model.FileId,
                                SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                            });
                            _context.SaveChanges();

                            containerData = _context.ContainerMaster.FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);
                        }
                        else
                        {
                            containerData.ContainerNo = model.ContainerNo;
                            containerData.FileId = model.FileId;
                            containerData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                            _context.ContainerMaster.Update(containerData);
                        }

                        _context.FileActivityLog.Add(new FileActivityLog
                        {
                            ContainerId = containerData.Id,
                            ActivityId = activityId,
                            StatusId = statusId,
                            UserId = user,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = DateTime.UtcNow,
                            Comment = model.Comment,
                            Roe = roeValue
                        });
                    }

                    _context.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else
            {
                var containerListData = _context.ContainerMaster.FirstOrDefault(x => (x.ContainerNo == model.ContainerNo && x.FileId == model.FileId) || (x.ContainerNo == null && x.FileId == model.FileId));
                var lastActivity = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId != model.ActivityId).OrderByDescending(x => x.EndDate).Select(x => x.ActivityId).FirstOrDefault();
                var fileActivityList = _context.FileActivityLog.Where(x => x.ContainerId == containerListData.Id && x.ActivityId == lastActivity && x.StatusId == completed).FirstOrDefault();

                if (ModelState.IsValid)
                {
                    if (containerListData != null)
                    {
                        _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                        {
                            FileLogId = model.FileLogId,
                            ActivityId = activityId,
                            StatusId = selectedStatusId,
                            UserId = userid,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                            Comment = fileComments,
                            Roe = roeValue
                        });
                        _context.SaveChanges();
                        var activities = new List<(string ActivityIds, string StatusId, string Comment)>();
                        if (activityId == SIToCarrier)
                        {
                            activities = new List<(string ActivityIds, string StatusId, string Comment)>
                            {
                                (activityId, statusId, model.Comment),
                            };
                        }
                        else
                        {
                            activities = new List<(string ActivityIds, string StatusId, string Comment)>
                            {
                                (activityId, statusId, model.Comment),
                            };
                        }

                        foreach (var (activityIds, statusIds, comment) in activities)
                        {
                            var fileLog = _context.FileActivityLog.Include(x => x.ContainerMaster)
                                .FirstOrDefault(x => x.ContainerId == containerListData.Id && x.ActivityId == activityIds);
                            
                            if (fileLog != null)
                            {
                                containerListData.ContainerNo = model.ContainerNo;
                                containerListData.FileId = model.FileId;
                                containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                fileLog.ActivityId = activityIds;
                                fileLog.StatusId = statusIds;
                                fileLog.UserId = userid;
                                fileLog.StartDate = Convert.ToDateTime(model.StartDate.ToString()).ToUniversalTime();
                                fileLog.EndDate = DateTime.UtcNow;
                                fileLog.Comment = comment;
                                fileLog.Roe = model.Roe;
                                _context.FileActivityLog.Update(fileLog);
                                _context.ContainerMaster.Update(containerListData);
                                _context.SaveChanges();
                            }
                            else
                            {
                                if (containerListData != null)
                                {
                                    containerListData.SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime();
                                    _context.ContainerMaster.Update(containerListData);
                                }
                                _context.FileActivityLog.Add(new FileActivityLog
                                {
                                    ContainerId = containerListData.Id,
                                    ActivityId = activityIds,
                                    StatusId = statusIds,
                                    UserId = null,
                                    StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                    EndDate = DateTime.UtcNow,
                                    Comment = comment,
                                    Roe = model.Roe
                                });
                                _context.SaveChanges();
                            }

                            if (activityList.NameOfActivity.ToLower().Contains("final bl") || activityList.NameOfActivity.ToLower().Contains("invoice") || activityList.NameOfActivity.ToLower().Contains("pre-alert") || activityList.NameOfActivity.ToLower().Contains("shipping confirmation"))
                            {
                                var activityListData = _context.ActivityMaster.Where(x => (x.NameOfActivity.ToLower().Contains(activityList.NameOfActivity.ToLower())) && x.ActivityType.ToLower() == "hbl").FirstOrDefault();
                                var hblListData = _context.HBLMaster.Where(x => x.ContainerId == model.ContainerId).ToList();
                                if (hblListData != null)
                                {
                                    foreach (var hbl in hblListData)
                                    {
                                        var hblActivityListData = _context.HBLActivityLog.FirstOrDefault(x => x.HBLId == hbl.Id && x.ActivityId == activityListData.Id);
                                        if (hblActivityListData != null)
                                        {
                                            var hblHistoryListData = _context.HBLActivitylogHistory.FirstOrDefault(x => x.HblLogId == hblActivityListData.Id && x.ActivityId == activityListData.Id);
                                            if (hblActivityListData != null)
                                            {
                                                _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
                                                {
                                                    HblLogId = activityListData.Id,
                                                    ActivityId = activityListData.Id,
                                                    StatusId = model.StatusId,
                                                    UserId = userid,
                                                    StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                                    EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                                                    Comment = model.Comment
                                                });
                                            }

                                            var hblLog = _context.HBLActivityLog.FirstOrDefault(x => x.Id == hblActivityListData.Id && x.ActivityId == activityListData.Id);
                                            if (hblLog != null)
                                            {
                                                hblLog.ActivityId = activityListData.Id;
                                                hblLog.StatusId = model.StatusId;
                                                hblLog.UserId = userid;
                                                hblLog.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                                hblLog.EndDate = DateTime.UtcNow;
                                                hblLog.Comment = model.Comment;
                                                _context.HBLActivityLog.Update(hblLog);
                                            }
                                            else
                                            {
                                                _context.HBLActivityLog.Add(new HBLActivityLog
                                                {
                                                    HBLId = hbl.Id,
                                                    ActivityId = activityListData.Id,
                                                    StatusId = model.StatusId,
                                                    UserId = userid,
                                                    StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                                    EndDate = DateTime.UtcNow,
                                                    Comment = model.Comment
                                                });
                                            }
                                        }
                                        else
                                        {                                            
                                            _context.HBLActivityLog.Add(new HBLActivityLog
                                            {
                                                HBLId = hbl.Id,
                                                ActivityId = activityListData.Id,
                                                StatusId = model.StatusId,
                                                UserId = userid,
                                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                                EndDate = DateTime.UtcNow,
                                                Comment = model.Comment
                                            });
                                        }
                                    }
                                }
                            }
                        }

                        _context.SaveChanges();
                        return Json("Success");
                    }
                    else
                    {
                        _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                        {
                            FileLogId = model.FileLogId,
                            ActivityId = activityId,
                            StatusId = selectedStatusId,
                            UserId = userid,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                            Comment = fileComments,
                            Roe = roeValue
                        });
                        _context.SaveChanges();

                        var containersListData = _context.ContainerMaster
                            .FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);
                        _context.ContainerMaster.Add(new ContainerMaster
                        {
                            ContainerNo = model.ContainerNo,
                            FileId = model.FileId,
                            SICutOff = Convert.ToDateTime(model.SI).ToUniversalTime()
                        });
                        _context.SaveChanges();

                        var containerData = _context.ContainerMaster
                            .FirstOrDefault(x => x.ContainerNo == model.ContainerNo && x.FileId == model.FileId);

                        _context.FileActivityLog.Add(new FileActivityLog
                        {
                            ContainerId = containerData.Id,
                            ActivityId = activityId,
                            StatusId = statusId,
                            UserId = userid,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = DateTime.UtcNow,
                            Comment = model.Comment,
                            Roe = model.Roe
                        });

                        if (activityList.NameOfActivity.ToLower().Contains("final bl") || activityList.NameOfActivity.ToLower().Contains("invoice") || activityList.NameOfActivity.ToLower().Contains("pre-alert") || activityList.NameOfActivity.ToLower().Contains("shipping confirmation"))
                        {
                            var activityListData = _context.ActivityMaster.Where(x => (x.NameOfActivity.ToLower().Contains(activityList.NameOfActivity.ToLower())) && x.ActivityType.ToLower() == "hbl").FirstOrDefault();
                            var hblListData = _context.HBLMaster.Where(x => x.ContainerId == model.ContainerId).ToList();
                            if (hblListData != null)
                            {
                                foreach (var hbl in hblListData)
                                {
                                    var hblActivityListData = _context.HBLActivityLog.FirstOrDefault(x => x.HBLId == hbl.Id && x.ActivityId == activityListData.Id);
                                    if (hblActivityListData != null)
                                    {
                                        var hblHistoryListData = _context.HBLActivitylogHistory.FirstOrDefault(x => x.HblLogId == hblActivityListData.Id && x.ActivityId == activityListData.Id);
                                        if (hblActivityListData != null)
                                        {
                                            _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
                                            {
                                                HblLogId = activityListData.Id,
                                                ActivityId = activityListData.Id,
                                                StatusId = model.StatusId,
                                                UserId = userid,
                                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                                EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                                                Comment = model.Comment
                                            });
                                        }
                                        
                                        var hblLog = _context.HBLActivityLog.FirstOrDefault(x => x.Id == hblActivityListData.Id && x.ActivityId == activityListData.Id);
                                        if (hblLog != null)
                                        {
                                            hblLog.ActivityId = activityListData.Id;
                                            hblLog.StatusId = model.StatusId;
                                            hblLog.UserId = userid;
                                            hblLog.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                            hblLog.EndDate = DateTime.UtcNow;
                                            hblLog.Comment = model.Comment;
                                            _context.HBLActivityLog.Update(hblLog);
                                        }
                                        else
                                        {
                                            _context.HBLActivityLog.Add(new HBLActivityLog
                                            {
                                                HBLId = hbl.Id,
                                                ActivityId = activityListData.Id,
                                                StatusId = model.StatusId,
                                                UserId = userid,
                                                StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                                EndDate = DateTime.UtcNow,
                                                Comment = model.Comment
                                            });
                                        }
                                    }
                                    else
                                    {
                                        _context.HBLActivityLog.Add(new HBLActivityLog
                                        {
                                            HBLId = hbl.Id,
                                            ActivityId = activityListData.Id,
                                            StatusId = model.StatusId,
                                            UserId = userid,
                                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                                            EndDate = DateTime.UtcNow,
                                            Comment = model.Comment
                                        });
                                    }
                                }
                            }
                        }

                        _context.SaveChanges();
                        return Json("Success");
                    }
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
        }

        [HttpGet]
        public IActionResult COB()
        {
            ViewData["CountryId"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetCOBs(string country, string fileNumber, string activity, string search, string type)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int cobrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            var cobData = _context.COBActivity
                .Include(x => x.ApplicationUser)
                .Include(x => x.Status)
                .Include(x => x.HBLMaster).ThenInclude(x => x.ContainerMaster).ThenInclude(x => x.FileMaster).ThenInclude(x => x.CountryMaster)
                .Select(x => new COBActivityViewModel
                {
                    Id = x.Id,
                    HBLId = x.HBLId,
                    EnterDate = x.HBLMaster.EnterDate,
                    POD = x.HBLMaster.ContainerMaster.FileMaster.CountryMaster.CountryName,
                    FileNumber = x.HBLMaster.ContainerMaster.FileMaster.FileNumber,
                    ContainerNo = x.HBLMaster.ContainerMaster.ContainerNo,
                    HBLNumber = x.HBLMaster.HBLNumber,
                    Booking = x.HBLMaster.Booking,
                    USABooking = x.USABooking,
                    ETD = x.ETD,
                    UserId = x.ApplicationUser.UserName,
                    StatusId = x.Status.Status,
                    Comment = x.Comment,
                    StartDate = x.StartDate,
                    EndDate = x.EndDate
                }).OrderBy(x => x.ETD).AsQueryable();

            IQueryable<COBActivityViewModel> data = cobData.AsQueryable();

            if (string.IsNullOrEmpty(sortColumn))
            {
                sortColumn = "etd";
            }

            var cob = data.OrderBy(sortColumn + " " + sortColumnDirection).ToList();            
            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);
            data = data.OrderByDescending(x => x.ETD.HasValue && x.ETD.Value.Date == DateTime.UtcNow.Date);

            cob = cob.Select(x => new COBActivityViewModel
            {
                Id = x.Id,
                HBLId = x.HBLId,
                HBLNumber = x.HBLNumber,
                FileNumber = x.FileNumber.Substring(0, x.FileNumber.Length - 6),
                EnterDate = x.EnterDate,
                POD = x.POD,
                Booking = x.Booking,
                ContainerNo = x.ContainerNo,
                USABooking = x.USABooking,
                ETD = x.ETD,
                UserId = x.UserId,
                StatusId = x.StatusId,
                Comment = x.Comment,
                StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
            }).OrderBy(x => x.ETD).ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = cobData.Count(),
                recordsFiltered = cob.Count(),
                data = cob
            });
        }

        [HttpPost]
        public JsonResult AddCOBActivities(COBActivityViewModel model, string button, string? statusValue, string? startDateValue, string? endDateValue, string? hblComments, string? etdValue, string? usaBookingValue)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            var editData = _context.COBActivity.FirstOrDefault(x => x.HBLId == model.HBLId);
            var wip = _context.StatusMaster.FirstOrDefault(x => x.Status == "WIP" && x.IsActive == true && x.IsDelete == false);
            var statusList = _context.StatusMaster.FirstOrDefault(x => x.Status == statusValue && x.IsActive == true && x.IsDelete == false);
            var cobList = _context.COBActivity.FirstOrDefault(x => x.HBLId == model.HBLId);
            var userList = _context.Users.FirstOrDefault(x => x.UserName == model.UserId && x.IsActive == true && x.IsDelete == false);
            string? userId = (userList != null) ? userList?.Id : null;
            string? selectedStatusId = (statusValue != "UnAllocated") ? statusList?.Id : null;

            if (button == "Edit")
            {
                if (ModelState.IsValid)
                {
                    var cobactivityList = _context.COBActivity.FirstOrDefault(x => x.HBLId == model.HBLId);

                    if (cobactivityList != null)
                    {
                        cobactivityList = _context.COBActivity.Include(x => x.Status).Include(x => x.ApplicationUser).Include(x => x.HBLMaster).FirstOrDefault(x => x.HBLId == model.HBLId);
                        if (cobactivityList != null && cobactivityList.Status != null)
                        {
                            if (editData != null && model.StatusId != wip.Status)
                            {
                                cobList.USABooking = model.USABooking;
                                cobList.ETD = model.ETD;
                                cobList.StatusId = wip.Id;
                                cobList.UserId = userid;
                                cobList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                _context.COBActivity.Update(cobList);
                            }
                            else if (editData != null && model.StatusId == wip.Status && editData.UserId == userid)
                            {
                                cobList.USABooking = model.USABooking;
                                cobList.ETD = model.ETD;
                                cobList.StatusId = wip.Id;
                                cobList.UserId = userid;
                                cobList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                _context.COBActivity.Update(cobList);
                            }
                            else
                            {
                                return Json("COB is processed by other user");
                            }
                        }
                        else
                        {
                            if (editData != null && model.StatusId != wip.Status)
                            {
                                cobList.USABooking = model.USABooking;
                                cobList.ETD = model.ETD;
                                cobList.StatusId = wip.Id;
                                cobList.UserId = userid;
                                cobList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                _context.COBActivity.Update(cobList);
                            }
                            else if (editData != null && model.StatusId == wip.Status && editData.UserId == userid)
                            {
                                cobList.USABooking = model.USABooking;
                                cobList.ETD = model.ETD;
                                cobList.StatusId = wip.Id;
                                cobList.UserId = userid;
                                cobList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                _context.COBActivity.Update(cobList);
                            }
                            else
                            {
                                return Json("COB is processed by other user");
                            }
                        }

                    }
                    
                    _context.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else if (button == "Cancel")
            {
                if (ModelState.IsValid)
                {
                    if (editData != null)
                    {
                        cobList.USABooking = usaBookingValue;
                        cobList.ETD = Convert.ToDateTime(etdValue);
                        cobList.StatusId = selectedStatusId;
                        cobList.UserId = userId;
                        cobList.StartDate = Convert.ToDateTime(startDateValue).ToUniversalTime();
                        cobList.EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime();
                        _context.COBActivity.Update(cobList);
                    }
                    _context.SaveChanges();

                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else
            {
                if (ModelState.IsValid)
                {
                    var cobListData = _context.COBActivity.Include(x => x.HBLMaster).Include(x => x.Status).Include(x => x.ApplicationUser).FirstOrDefault(x => x.HBLId == model.HBLId);
                    if (cobListData != null)
                    {
                        _context.COBActivityHistory.Add(new COBActivityHistory
                        {
                            COBActivityId = cobListData.Id,
                            Booking  = cobListData.HBLMaster.Booking,
                            USABooking = cobListData.USABooking,
                            ETD = cobListData.ETD,
                            StatusId = cobListData.StatusId,
                            Comment = cobListData.Comment,
                            UserId = cobListData.UserId,
                            StartDate = cobListData.StartDate,
                            EndDate  = cobListData.EndDate
                        });

                        var cobLog = _context.COBActivity.FirstOrDefault(x => x.Id == cobListData.Id);
                        if (cobLog != null)
                        {
                            if (model.StatusId == null || model.StatusId == wip.Id)
                            {
                                cobLog.USABooking = model.USABooking;
                                cobLog.ETD = model.ETD;
                                cobLog.StatusId = model.StatusId;
                                cobLog.UserId = userid;
                                //cobLog.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                //cobLog.EndDate = DateTime.UtcNow;
                                cobLog.Comment = model.Comment;
                                _context.COBActivity.Update(cobLog);
                            }
                            else
                            {
                                cobLog.USABooking = model.USABooking;
                                cobLog.ETD = model.ETD;
                                cobLog.StatusId = model.StatusId;
                                cobLog.UserId = userid;
                                cobLog.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                cobLog.EndDate = DateTime.UtcNow;
                                cobLog.Comment = model.Comment;
                                _context.COBActivity.Update(cobLog);
                            }
                        }
                    }
                    
                    _context.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
        }

        [HttpGet]
        public IActionResult DAP()
        {
            ViewData["CountryId"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetDAPs(string country, string fileNumber, string activity, string search, string type)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int cobrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            var dapData = _context.DAPActivity
                .Include(x => x.ApplicationUser)
                .Include(x => x.Status)
                .Include(x => x.HBLMaster).ThenInclude(x => x.ContainerMaster).ThenInclude(x => x.FileMaster).ThenInclude(x => x.CountryMaster)
                .Select(x => new DAPActivityViewModel
                {
                    Id = x.Id,
                    HBLId = x.HBLId,
                    EnterDate = x.HBLMaster.EnterDate,
                    POD = x.HBLMaster.CountryMaster.CountryName,
                    FileNumber = x.HBLMaster.ContainerMaster.FileMaster.FileNumber,
                    ContainerNo = x.HBLMaster.ContainerMaster.ContainerNo,
                    HBLNumber = x.HBLMaster.HBLNumber,
                    Booking = x.HBLMaster.Booking,
                    VesselETA = x.VesselETA,
                    VesselETADay = Convert.ToDateTime(x.VesselETA).DayOfWeek.ToString(),
                    UserId = x.ApplicationUser.UserName,
                    StatusId = x.Status.Status,
                    FirstReminder = x.FirstReminder,
                    FirstReminderStatus = _context.StatusMaster.Where(s => s.Id == x.FirstReminderStatus).Select(x => x.Status).FirstOrDefault(),
                    FirstReminderComment = x.FirstReminderComment,
                    SecondReminder = x.SecondReminder,
                    SecondReminderStatus = _context.StatusMaster.Where(s => s.Id == x.SecondReminderStatus).Select(x => x.Status).FirstOrDefault(),
                    SecondReminderComment = x.SecondReminderComment,
                    ThirdReminder = x.ThirdReminder,
                    ThirdReminderStatus = _context.StatusMaster.Where(s => s.Id == x.ThirdReminderStatus).Select(x => x.Status).FirstOrDefault(),
                    ThirdReminderComment = x.ThirdReminderComment,
                    StartDate = x.StartDate,
                    EndDate = x.EndDate
                }).OrderBy(x => x.VesselETA).AsQueryable();

            IQueryable<DAPActivityViewModel> data = dapData.AsQueryable();
            
            if (string.IsNullOrEmpty(sortColumn))
            {
                sortColumn = "vesselETA";
            }

            var dap = data.OrderBy(sortColumn + " " + sortColumnDirection).ToList();            
            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);

            data = data.OrderByDescending(x => x.VesselETA.HasValue && x.VesselETA.Value.Date == DateTime.UtcNow.Date ||
                        x.FirstReminder.HasValue && x.FirstReminder.Value.Date == DateTime.UtcNow.Date ||
                        x.SecondReminder.HasValue && x.SecondReminder.Value.Date == DateTime.UtcNow.Date ||
                        x.ThirdReminder.HasValue && x.ThirdReminder.Value.Date == DateTime.UtcNow.Date);

            dap = dap.Select(x => new DAPActivityViewModel
            {
                Id = x.Id,
                HBLId = x.HBLId,
                EnterDate = x.EnterDate,
                POD = x.POD,
                FileNumber = x.FileNumber != null ? x.FileNumber.Substring(0, x.FileNumber.Length - 6) : x.FileNumber,
                ContainerNo = x.ContainerNo,
                HBLNumber = x.HBLNumber,
                Booking = x.Booking,
                VesselETA = x.VesselETA,
                VesselETADay = x.VesselETADay,
                UserId = x.UserId,
                StatusId = x.StatusId,
                FirstReminder = x.FirstReminder,
                FirstReminderStatus = x.FirstReminderStatus,
                FirstReminderComment = x.FirstReminderComment,
                SecondReminder = x.SecondReminder,
                SecondReminderStatus = x.SecondReminderStatus,
                SecondReminderComment = x.SecondReminderComment,
                ThirdReminder = x.ThirdReminder,
                ThirdReminderStatus = x.ThirdReminderStatus,
                ThirdReminderComment = x.ThirdReminderComment,
                StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
            }).OrderBy(x => x.VesselETA).ToList();

            return Json(new
            {
                draw = draw,
                recordsTotal = dapData.Count(),
                recordsFiltered = dap.Count(),
                data = dap
            });
        }

        [HttpPost]
        public JsonResult AddDAPActivities(DAPActivityViewModel model, string button, string? statusValue, string? startDateValue, string? endDateValue, string? vesselETAValue, string? firstStatusValue, string? firstCommentValue, string? secondStatusValue, string? secondCommentValue, string? thirdStatusValue, string? thirdCommentValue)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
            var editData = _context.DAPActivity.FirstOrDefault(x => x.HBLId == model.HBLId);
            var wip = _context.StatusMaster.FirstOrDefault(x => x.Status == "WIP" && x.IsActive == true && x.IsDelete == false);
            var completed = _context.StatusMaster.FirstOrDefault(x => x.Status == "Completed" && x.IsActive == true && x.IsDelete == false);
            var statusList = _context.StatusMaster.FirstOrDefault(x => x.Status == statusValue && x.IsActive == true && x.IsDelete == false);
            var dapList = _context.DAPActivity.FirstOrDefault(x => x.HBLId == model.HBLId);
            var userList = _context.Users.FirstOrDefault(x => x.UserName == model.UserId && x.IsActive == true && x.IsDelete == false);
            string? userId = (userList != null) ? userList?.Id : null;
            string? selectedStatusId = (statusValue != "UnAllocated") ? statusList?.Id : null;

            if (button == "Edit")
            {
                if (ModelState.IsValid)
                {
                    var dapactivityList = _context.DAPActivity.FirstOrDefault(x => x.HBLId == model.HBLId);

                    if (dapactivityList != null)
                    {
                        dapactivityList = _context.DAPActivity.Include(x => x.Status).Include(x => x.ApplicationUser).Include(x => x.HBLMaster).FirstOrDefault(x => x.HBLId == model.HBLId);
                        if (dapactivityList != null && dapactivityList.Status != null)
                        {
                            if (dapactivityList.Status.Status != "Completed")
                            {
                                if (dapactivityList.FirstReminderStatus == null && model.FirstReminderStatus == null)
                                {
                                    dapList.VesselETA = model.VesselETA;
                                    dapList.FirstReminderStatus = wip.Id;
                                    dapList.StatusId = wip.Id;
                                    dapList.UserId = userid;
                                    dapList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                    _context.DAPActivity.Update(dapList);
                                }
                                else if (dapactivityList.FirstReminderStatus != null && model.SecondReminderStatus != null && dapactivityList.SecondReminderStatus == null)
                                {
                                    if (editData != null && model.FirstReminderStatus != completed.Id && dapactivityList.FirstReminderStatus != completed.Id)
                                    {
                                        dapList.VesselETA = model.VesselETA;
                                        dapList.SecondReminderStatus = wip.Id;
                                        //dapList.StatusId = wip.Id;
                                        dapList.UserId = userid;
                                        dapList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                        _context.DAPActivity.Update(dapList);
                                    }
                                }
                                else if (dapactivityList.SecondReminderStatus != null && model.ThirdReminderStatus != null && dapactivityList.ThirdReminderStatus == null)
                                {
                                    if (editData != null && model.SecondReminderStatus != completed.Id && dapactivityList.SecondReminderStatus != completed.Id)
                                    {
                                        dapList.VesselETA = model.VesselETA;
                                        dapList.ThirdReminderStatus = wip.Id;
                                        //dapList.StatusId = wip.Id;
                                        dapList.UserId = userid;
                                        dapList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                        _context.DAPActivity.Update(dapList);
                                    }
                                }
                                else if (dapactivityList.SecondReminderStatus != null && model.ThirdReminderStatus != null && dapactivityList.ThirdReminderStatus != "Completed")
                                {
                                    dapList.VesselETA = model.VesselETA;
                                    dapList.ThirdReminderStatus = wip.Id;
                                    //dapList.StatusId = wip.Id;
                                    dapList.UserId = userid;
                                    dapList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                    _context.DAPActivity.Update(dapList);
                                }
                            }
                            else
                            {
                                return Json("DAP is processed by other user");
                            }
                        }
                        else
                        {
                            if (dapactivityList.FirstReminderStatus == null && model.FirstReminderStatus == null)
                            {
                                dapList.VesselETA = model.VesselETA;
                                dapList.FirstReminderStatus = wip.Id;
                                dapList.StatusId = wip.Id;
                                dapList.UserId = userid;
                                dapList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                _context.DAPActivity.Update(dapList);
                            }
                            else if (dapactivityList.FirstReminderStatus != null && model.SecondReminderStatus != null)
                            {
                                if (editData != null && model.FirstReminderStatus != completed.Id && dapactivityList.FirstReminderStatus != completed.Id)
                                {
                                    dapList.VesselETA = model.VesselETA;
                                    dapList.SecondReminderStatus = wip.Id;
                                    //dapList.StatusId = wip.Id;
                                    dapList.UserId = userid;
                                    dapList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                    _context.DAPActivity.Update(dapList);
                                }
                            }
                            else if (dapactivityList.SecondReminderStatus != null && model.ThirdReminder != null)
                            {
                                if (editData != null && model.SecondReminderStatus != completed.Id && dapactivityList.SecondReminderStatus != completed.Id)
                                {
                                    dapList.VesselETA = model.VesselETA;
                                    dapList.ThirdReminderStatus = wip.Id;
                                    //dapList.StatusId = wip.Id;
                                    dapList.UserId = userid;
                                    dapList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                    _context.DAPActivity.Update(dapList);
                                }
                            }
                            else if (dapactivityList.SecondReminderStatus != null && model.ThirdReminder != null && dapactivityList.ThirdReminderStatus != "Completed")
                            {
                                dapList.VesselETA = model.VesselETA;
                                dapList.ThirdReminderStatus = wip.Id;
                                //dapList.StatusId = wip.Id;
                                dapList.UserId = userid;
                                dapList.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                _context.DAPActivity.Update(dapList);
                            }
                            else
                            {
                                return Json("DAP is processed by other user");
                            }
                        }
                    }
                    
                    _context.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
            else if (button == "Cancel")
            {
                if (ModelState.IsValid)
                {
                    var dapactivityList = _context.DAPActivity.FirstOrDefault(x => x.HBLId == model.HBLId);

                    if (dapactivityList != null)
                    {
                        dapactivityList = _context.DAPActivity.Include(x => x.Status).Include(x => x.ApplicationUser).Include(x => x.HBLMaster).FirstOrDefault(x => x.HBLId == model.HBLId);
                        if (dapactivityList != null && dapactivityList.Status != null)
                        {
                            if (dapactivityList.Status.Status != "Completed")
                            {
                                if (dapactivityList.FirstReminderStatus == null && model.FirstReminderStatus == null)
                                {
                                    dapList.VesselETA = Convert.ToDateTime(vesselETAValue);
                                    dapList.FirstReminderStatus = firstStatusValue;
                                    dapList.UserId = userid;
                                    dapList.StartDate = Convert.ToDateTime(startDateValue).ToUniversalTime();
                                    dapList.EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime();
                                    _context.DAPActivity.Update(dapList);
                                }
                                else if (dapactivityList.FirstReminderStatus != null && model.SecondReminderStatus != null)
                                {
                                    if (editData != null && model.FirstReminderStatus != completed.Id && dapactivityList.FirstReminderStatus != completed.Id)
                                    {
                                        dapList.VesselETA = Convert.ToDateTime(vesselETAValue);
                                        dapList.SecondReminderStatus = secondStatusValue;
                                        dapList.UserId = userid;
                                        dapList.StartDate = Convert.ToDateTime(startDateValue).ToUniversalTime();
                                        dapList.EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime();
                                        _context.DAPActivity.Update(dapList);
                                    }
                                }
                                else if (dapactivityList.SecondReminderStatus != null && model.ThirdReminder != null)
                                {
                                    if (editData != null && model.SecondReminderStatus != completed.Id && dapactivityList.SecondReminderStatus != completed.Id)
                                    {
                                        dapList.VesselETA = Convert.ToDateTime(vesselETAValue);
                                        dapList.ThirdReminderStatus = thirdStatusValue;
                                        dapList.UserId = userid;
                                        dapList.StartDate = Convert.ToDateTime(startDateValue).ToUniversalTime();
                                        dapList.EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime();
                                        _context.DAPActivity.Update(dapList);
                                    }
                                }
                            }

                            _context.SaveChanges();
                            return Json("Success");
                        }
                        else
                        {
                            return Json("Error while processing the request");
                        }
                    }
                    else
                    {
                        if (ModelState.IsValid)
                        {
                            var dapListData = _context.DAPActivity.FirstOrDefault(x => x.HBLId == model.HBLId);
                            if (dapListData != null)
                            {
                                var dapLog = _context.DAPActivity.FirstOrDefault(x => x.Id == dapListData.Id);
                                if (dapLog != null)
                                {
                                    dapLog.VesselETA = model.VesselETA;
                                    dapLog.StatusId = model.StatusId;
                                    dapLog.UserId = userid;
                                    dapLog.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                    dapLog.EndDate = DateTime.UtcNow;
                                    dapLog.FirstReminderComment = model.FirstReminderComment;
                                    _context.DAPActivity.Update(dapLog);
                                }
                            }
                            _context.SaveChanges();
                            return Json("Success");
                        }
                        else
                        {
                            return Json("Error while processing the request");
                        }
                    }
                }
            }
            else
            {
                if (ModelState.IsValid)
                {
                    var dapListData = _context.DAPActivity.FirstOrDefault(x => x.HBLId == model.HBLId);
                    if (dapListData != null)
                    {
                        DateTime vesselETA7 = Convert.ToDateTime(model.VesselETA);
                        DateTime vesselETA5 = Convert.ToDateTime(model.VesselETA);
                        var VesselETADay7 = vesselETA7.DayOfWeek.ToString();
                        var VesselETADay5 = vesselETA5.DayOfWeek.ToString();

                        if (dapListData.FirstReminder == null)
                        {
                            vesselETA7 = model.VesselETA.Value.AddDays(7);
                            vesselETA5 = model.VesselETA.Value.AddDays(5);
                            VesselETADay7 = vesselETA7.DayOfWeek.ToString();
                            VesselETADay5 = vesselETA5.DayOfWeek.ToString();                            
                        }
                        else if (dapListData.FirstReminder != null && dapListData.SecondReminder == null)
                        {
                            vesselETA7 = dapListData.FirstReminder.Value.AddDays(7);
                            vesselETA5 = dapListData.FirstReminder.Value.AddDays(5);
                            VesselETADay7 = vesselETA7.DayOfWeek.ToString();
                            VesselETADay5 = vesselETA5.DayOfWeek.ToString();
                        }
                        else if (dapListData.SecondReminder != null && dapListData.ThirdReminder == null)
                        {
                            vesselETA7 = dapListData.SecondReminder.Value.AddDays(7);
                            vesselETA5 = dapListData.SecondReminder.Value.AddDays(5);
                            VesselETADay7 = vesselETA7.DayOfWeek.ToString();
                            VesselETADay5 = vesselETA5.DayOfWeek.ToString();
                        }

                        if (VesselETADay7 == "Sunday")
                        {
                            vesselETA7 = vesselETA7.AddDays(1);
                        }
                        if (VesselETADay7 == "Saturday")
                        {
                            vesselETA7 = vesselETA7.AddDays(-1);
                        }
                        if (VesselETADay5 == "Sunday")
                        {
                            vesselETA5 = vesselETA5.AddDays(1);
                        }
                        if (VesselETADay5 == "Saturday")
                        {
                            vesselETA5 = vesselETA5.AddDays(-1);
                        }
                        
                        _context.DAPActvityHistory.Add(new DAPActvityHistory
                        {
                            DapActivityId = dapListData.Id,
                            VesselETA = model.VesselETA,
                            FirstReminder = dapListData.FirstReminder == null ? DateTime.UtcNow : dapListData.FirstReminder,
                            SecondReminder = dapListData.SecondReminder == null ? DateTime.UtcNow : dapListData.SecondReminder,
                            ThirdReminder = dapListData.ThirdReminder == null ? DateTime.UtcNow : dapListData.ThirdReminder,
                            FirstReminderStatus = dapListData.FirstReminderStatus == null ? model.FirstReminderStatus : dapListData.FirstReminderStatus,
                            SecondReminderStatus = dapListData.SecondReminderStatus == null ? model.SecondReminderStatus : dapListData.SecondReminderStatus,
                            ThirdReminderStatus = dapListData.ThirdReminderStatus == null ? model.ThirdReminderStatus : dapListData.ThirdReminderStatus,
                            FirstReminderComment = dapListData.FirstReminderComment == null ? model.FirstReminderComment : dapListData.FirstReminderComment,
                            SecondReminderComment = dapListData.SecondReminderComment == null ? model.SecondReminderComment : dapListData.SecondReminderComment,
                            ThirdReminderComment = dapListData.ThirdReminderComment == null ? model.ThirdReminderComment : dapListData.ThirdReminderComment,
                            UserId = userid,
                            StatusId = dapListData.StatusId == null ? model.StatusId : dapListData.StatusId,
                            StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime(),
                            EndDate = Convert.ToDateTime(endDateValue).ToUniversalTime(),
                        });
                        _context.SaveChanges();

                        dapListData = _context.DAPActivity.Include(x => x.Status).Include(x => x.ApplicationUser).Include(x => x.HBLMaster).FirstOrDefault(x => x.HBLId == model.HBLId);
                        if (dapListData != null && dapListData.Status != null)
                        {
                            if (dapListData.Status.Status != "Completed")
                            {
                                var dapLog = _context.DAPActivity.FirstOrDefault(x => x.Id == dapListData.Id);
                                if ((dapListData.VesselETA == null || dapLog.VesselETA == null))
                                {
                                    if (dapLog != null)
                                    {
                                        dapLog.VesselETA = model.VesselETA;
                                        dapLog.UserId = userid;
                                        dapLog.FirstReminder = vesselETA5;
                                        _context.DAPActivity.Update(dapLog);
                                    }
                                }
                                else if ((dapListData.FirstReminderStatus == null || dapListData.FirstReminderStatus == wip.Id) && (model.FirstReminderStatus != null || model.FirstReminderStatus == wip.Id))
                                {
                                    if (dapLog != null)
                                    {
                                        dapLog.VesselETA = model.VesselETA;
                                        dapLog.FirstReminderStatus = model.FirstReminderStatus;
                                        dapLog.StatusId = model.FirstReminderStatus;
                                        dapLog.UserId = userid;
                                        dapLog.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                        dapLog.EndDate = DateTime.UtcNow;
                                        dapLog.FirstReminder = vesselETA5;
                                        dapLog.FirstReminderComment = model.FirstReminderComment;
                                        if (model.FirstReminderStatus != completed.Id)
                                        {
                                            dapLog.SecondReminder = vesselETA7;
                                        }
                                        _context.DAPActivity.Update(dapLog);
                                    }
                                }
                                else if (dapListData.FirstReminderStatus != null && (dapListData.SecondReminderStatus == null || dapListData.SecondReminderStatus == wip.Id) && (model.SecondReminderStatus != null || model.SecondReminderStatus == wip.Id))
                                {
                                    if (editData != null && model.FirstReminderStatus != completed.Id && dapListData.FirstReminderStatus != completed.Id)
                                    {
                                        dapLog.VesselETA = model.VesselETA;
                                        dapLog.SecondReminderStatus = model.SecondReminderStatus;
                                        dapLog.StatusId = model.SecondReminderStatus;
                                        dapLog.UserId = userid;
                                        dapLog.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                        dapLog.EndDate = DateTime.UtcNow;
                                        //dapLog.SecondReminder = vesselETA7;
                                        dapLog.SecondReminderComment = model.SecondReminderComment;
                                        if (model.SecondReminderStatus != completed.Id)
                                        {
                                            dapLog.ThirdReminder = vesselETA7;
                                        }
                                        _context.DAPActivity.Update(dapLog);
                                    }
                                }
                                else if (dapListData.SecondReminderStatus != null && (dapListData.ThirdReminderStatus == null || dapListData.ThirdReminderStatus == wip.Id) && (model.ThirdReminderStatus != null || model.ThirdReminderStatus == wip.Id))
                                {
                                    if (editData != null && model.SecondReminderStatus != completed.Id && dapListData.SecondReminderStatus != completed.Id)
                                    {
                                        dapLog.VesselETA = model.VesselETA;
                                        dapLog.ThirdReminderStatus = model.ThirdReminderStatus;
                                        dapLog.StatusId = model.ThirdReminderStatus;
                                        dapLog.UserId = userid;
                                        dapLog.StartDate = Convert.ToDateTime(model.StartDate).ToUniversalTime();
                                        dapLog.EndDate = DateTime.UtcNow;
                                        //dapLog.ThirdReminder = vesselETA7;
                                        dapLog.ThirdReminderComment = model.ThirdReminderComment;
                                        _context.DAPActivity.Update(dapLog);
                                    }
                                }
                            }
                            
                            _context.SaveChanges();
                            return Json("Success");
                        }
                        else
                        {
                            return Json("Error while processing the request");
                        }
                    }
                }
            }

            _context.SaveChanges();
            return Json("Success");
        }

        [HttpGet]
        public IActionResult SelectRole()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            ViewData["AssignedRoles"] = _context.UserRoles.Where(x => x.UserId == userid).Select(x => new RoleNameList
            {
                RoleId = x.RoleId,
                RoleName = _context.Roles.Where(y => y.Id == x.RoleId).Select(x => x.Name).FirstOrDefault()
            }).ToList();

            return View();
        }

        [HttpGet]
        public IActionResult RoleAction(string RoleName)
        {
            if (RoleName.ToUpper().ToString() == "SUPERVISOR" || RoleName.ToUpper().ToString() == "MANAGER" || RoleName.ToUpper().ToString() == "ADMIN")
            {
                return RedirectToAction("Index", "Dashboard");
            }
            else if (RoleName.ToUpper().ToString() == "USER")
            {
                return RedirectToAction("HBL", "User");
            }
            else
            {
                return NotFound();
            }
            return View();
        }
    }
}