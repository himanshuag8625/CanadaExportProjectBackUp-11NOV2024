﻿namespace CanadaExportTrackX.ViewModels
{
    public class FileInsertModel
    {        
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string CountryId { get; set; }
        public string FileNumber { get; set; } = null!;
        public string? Container { get; set; }
        public string? ShippingAgent { get; set; }
        public string? ETAPOD { get; set; }
        public int? TotalHBL { get; set; }
        public string? FileContact { get; set; }
        public string? ShippingLine { get; set; }
        public string? ETA { get; set; }
        public string? ATD { get; set; }
        public string? ETD { get; set; }
        public string? SICutOff { get; set; }
        public DateTime? EnterDate { get; set; }=DateTime.Now;
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;
    }
}
